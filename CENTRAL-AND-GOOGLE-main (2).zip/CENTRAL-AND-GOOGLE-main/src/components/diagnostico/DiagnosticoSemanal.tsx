import { useMemo, useState, useRef, useEffect } from "react";
import { Campaign } from "@/data/mockMetaData";
import { groupCampaignsByFunnel } from "@/lib/funnelGrouping";
import { useWeeklyDiagnostic } from "@/hooks/useWeeklyDiagnostic";
import { useWeeklyNotes } from "@/hooks/useWeeklyNotes";
import { DiagnosticoFunnelSection } from "./DiagnosticoFunnelSection";
import { DiagnosticoBloco } from "./DiagnosticoBloco";
import { DiagnosticoPresentMode } from "./DiagnosticoPresentMode";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Sparkles, Save, Loader2, Presentation, ClipboardList, ArrowRight, RefreshCw, Archive, Plus } from "lucide-react";
import { toast } from "sonner";
import { useRefreshMetaAds } from "@/hooks/useMetaAds";
import { getPeriodPair, presetLabel } from "@/lib/period";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { useSaveDiagnostic } from "@/hooks/useSavedDiagnostics";
import { SavedDiagnosticsList } from "./SavedDiagnosticsList";
import { supabase } from "@/integrations/supabase/client";
import { GoogleAdsSummaryCard } from "@/components/dashboard/GoogleAdsSummaryCard";
import type { MetricsConfig } from "@/hooks/useDiagnosticMetricsConfig";
import { FunnelPreviewCard } from "@/components/funnel/FunnelPreviewCard";
import { FunnelPremiumDetailDialog } from "@/components/funnel/FunnelPremiumDetailDialog";
import { useManualFunnels, useCreateManualFunnel } from "@/hooks/useManualFunnels";

function formatPeriodRange(preset: string): string {
  const { current } = getPeriodPair(preset);
  const fmt = (d: Date) => d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
  return `${fmt(current.start)} – ${fmt(current.end)}`;
}

interface Props {
  clientId: string;
  clientName?: string;
  campaigns: Campaign[];
  datePreset: string;
  currencySymbol?: string;
}

const DATE_LABEL = new Proxy({} as Record<string, string>, {
  get: (_t, key: string) => presetLabel(key),
});

export function DiagnosticoSemanal({
  clientId,
  clientName = "Cliente",
  campaigns,
  datePreset,
  currencySymbol = "R$",
}: Props) {
  // Refresh forçado dos dados Meta (bypass cache)
  const refreshMeta = useRefreshMetaAds();
  const [refreshing, setRefreshing] = useState(false);
  const handleRefresh = async () => {
    if (!clientId) return;
    setRefreshing(true);
    try {
      await refreshMeta(clientId, datePreset);
      toast.success("Dados atualizados da Meta API!");
    } catch (e: any) {
      toast.error(e?.message || "Erro ao atualizar dados");
    } finally {
      setRefreshing(false);
    }
  };

  const periodRange = useMemo(() => formatPeriodRange(datePreset), [datePreset]);

  // Apenas campanhas com gasto no período
  const activeCampaigns = useMemo(
    () => campaigns.filter(c => c.spend > 0),
    [campaigns]
  );
  const groups = useMemo(() => groupCampaignsByFunnel(activeCampaigns), [activeCampaigns]);

  const { whatWeDid, setWhatWeDid, nextActions, setNextActions, save: saveNotes, saving: savingNotes } =
    useWeeklyNotes(clientId, datePreset);

  const { blocks, updateBlock, generating, generateWithAI, saving } =
    useWeeklyDiagnostic(clientId, datePreset);

  const [presenting, setPresenting] = useState(false);
  const docRef = useRef<HTMLDivElement>(null);
  const [createManualOpen, setCreateManualOpen] = useState(false);
  const [newManualCode, setNewManualCode] = useState("");
  const [newManualLabel, setNewManualLabel] = useState("");
  const [detailManual, setDetailManual] = useState<{ code: string; label: string } | null>(null);
  const { data: manualFunnels } = useManualFunnels(clientId);
  const createManual = useCreateManualFunnel();

  // Salvar snapshot
  const saveDiag = useSaveDiagnostic();
  const [saveOpen, setSaveOpen] = useState(false);
  const defaultTitle = `${clientName} — ${periodRange}`;
  const [saveTitle, setSaveTitle] = useState(defaultTitle);
  useEffect(() => { setSaveTitle(`${clientName} — ${periodRange}`); }, [clientName, periodRange]);

  const handleSaveSnapshot = async () => {
    if (!saveTitle.trim()) { toast.error("Dê um título ao diagnóstico"); return; }
    const { current } = getPeriodPair(datePreset);
    try {
      // Captura a config de métricas (visíveis + manuais) por funil/campanha
      // para que o diagnóstico salvo exiba exatamente o que o gestor editou.
      const { data: cfgRows } = await supabase
        .from("diagnostic_metrics_config")
        .select("group_key, visible_metrics, custom_metrics")
        .eq("client_id", clientId)
        .eq("date_preset", datePreset);
      const metricsConfig: Record<string, MetricsConfig> = {};
      for (const row of (cfgRows || []) as any[]) {
        metricsConfig[row.group_key] = {
          visible_metrics: Array.isArray(row.visible_metrics) ? row.visible_metrics : [],
          custom_metrics: Array.isArray(row.custom_metrics) ? row.custom_metrics : [],
        };
      }
      await saveDiag.mutateAsync({
        client_id: clientId,
        title: saveTitle.trim(),
        date_preset: datePreset,
        period_start: current.start.toISOString().slice(0, 10),
        period_end: current.end.toISOString().slice(0, 10),
        snapshot: {
          campaigns: activeCampaigns,
          blocks,
          whatWeDid,
          nextActions,
          periodRange,
          clientName,
          currencySymbol,
          metricsConfig,
        },
      });
      toast.success("Diagnóstico salvo!");
      setSaveOpen(false);
    } catch (e: any) {
      toast.error(e?.message || "Erro ao salvar");
    }
  };

  // Resumo enviado pra IA
  const summaryForAI = useMemo(() => {
    const totals = activeCampaigns.reduce(
      (acc, c) => {
        acc.spend += c.spend;
        acc.impressions += c.impressions;
        acc.clicks += c.clicks;
        acc.conversions += c.conversions;
        acc.purchaseValue += c.purchaseValue || 0;
        return acc;
      },
      { spend: 0, impressions: 0, clicks: 0, conversions: 0, purchaseValue: 0 }
    );
    const ctr = totals.impressions > 0 ? (totals.clicks / totals.impressions) * 100 : 0;
    const cpa = totals.conversions > 0 ? totals.spend / totals.conversions : 0;
    const roas = totals.spend > 0 && totals.purchaseValue > 0 ? totals.purchaseValue / totals.spend : 0;

    const lines: string[] = [];
    lines.push(`# Cliente: ${clientName}`);
    lines.push(`Período: ${DATE_LABEL[datePreset] || datePreset}`);
    lines.push("");
    lines.push("## Métricas globais");
    lines.push(`- Investimento total: ${currencySymbol} ${totals.spend.toFixed(2)}`);
    lines.push(`- Resultados totais: ${totals.conversions}`);
    lines.push(`- CPA médio: ${currencySymbol} ${cpa.toFixed(2)}`);
    lines.push(`- CTR médio: ${ctr.toFixed(2)}%`);
    if (roas > 0) lines.push(`- ROAS: ${roas.toFixed(2)}x`);
    lines.push("");
    lines.push(`## Funis e campanhas ativas (${groups.length})`);

    for (const g of groups) {
      const gSpend = g.campaigns.reduce((s, c) => s + c.spend, 0);
      const gConv = g.campaigns.reduce((s, c) => s + c.conversions, 0);
      const gImp = g.campaigns.reduce((s, c) => s + c.impressions, 0);
      const gClicks = g.campaigns.reduce((s, c) => s + c.clicks, 0);
      const gCtr = gImp > 0 ? (gClicks / gImp) * 100 : 0;
      const gCpa = gConv > 0 ? gSpend / gConv : 0;
      const label = g.isFunnel ? `Funil: ${g.key}` : `Campanha: ${g.key}`;

      lines.push("");
      lines.push(`### ${label}`);
      lines.push(`- Investimento: ${currencySymbol} ${gSpend.toFixed(2)}`);
      lines.push(`- Resultados: ${gConv}`);
      lines.push(`- CTR: ${gCtr.toFixed(2)}% | CPA: ${currencySymbol} ${gCpa.toFixed(2)}`);

      // Top 3 criativos do grupo
      const allCreatives = g.campaigns.flatMap(c =>
        c.creatives.map(cr => ({ ...cr, _camp: c.name }))
      );
      const top = allCreatives
        .filter(cr => cr.spend > 0 || cr.impressions > 0)
        .sort((a, b) => (b.primaryResult ?? b.conversions) - (a.primaryResult ?? a.conversions) || b.ctr - a.ctr)
        .slice(0, 3);
      if (top.length > 0) {
        lines.push("- Top criativos:");
        for (const cr of top) {
          const r = cr.primaryResult ?? cr.conversions;
          const cCpa = r > 0 ? cr.spend / r : 0;
          lines.push(`  • ${cr.name} (conjunto ${cr.adsetName || "—"}): ${r} resultados, CPA ${currencySymbol} ${cCpa.toFixed(2)}, CTR ${cr.ctr.toFixed(2)}%`);
        }
      }
    }

    lines.push("");
    lines.push("## Anotações do gestor");
    lines.push(`### O que fizemos esta semana\n${whatWeDid || "(sem anotações)"}`);
    lines.push("");
    lines.push(`### Próximas ações planejadas\n${nextActions || "(sem anotações)"}`);

    return lines.join("\n");
  }, [activeCampaigns, groups, whatWeDid, nextActions, clientName, datePreset, currencySymbol]);

  const handleGenerateAI = () => {
    if (activeCampaigns.length === 0) {
      toast.error("Sem campanhas com gasto no período para analisar.");
      return;
    }
    generateWithAI(summaryForAI);
  };

  const handleCreateManual = async () => {
    const code = newManualCode.trim().toUpperCase();
    const label = newManualLabel.trim();
    if (!code || !label) {
      toast.error("Informe código e nome");
      return;
    }
    try {
      await createManual.mutateAsync({ client_id: clientId, code, label });
      toast.success("Funil manual criado");
      setNewManualCode("");
      setNewManualLabel("");
      setCreateManualOpen(false);
    } catch (e: any) {
      toast.error(e?.message?.includes("duplicate") ? "Já existe um funil com esse código" : "Erro ao criar funil");
    }
  };

  // ESC fecha apresentação
  useEffect(() => {
    if (!presenting) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setPresenting(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [presenting]);

  return (
    <>
      <Tabs defaultValue="atual" className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <TabsList className="bg-card border border-border">
            <TabsTrigger value="atual">Como estamos agora</TabsTrigger>
            <TabsTrigger value="salvos" className="gap-1"><Archive className="h-3.5 w-3.5" /> Diagnósticos salvos</TabsTrigger>
          </TabsList>
          {activeCampaigns.length > 0 && (
            <div className="flex flex-wrap items-center gap-1">
              <Button onClick={handleRefresh} disabled={refreshing} variant="ghost" size="sm" className="h-8 px-2 gap-1.5 text-xs text-muted-foreground hover:text-foreground">
                {refreshing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
                Atualizar
              </Button>
              <Button onClick={handleGenerateAI} disabled={generating} variant="ghost" size="sm" className="h-8 px-2 gap-1.5 text-xs text-primary hover:text-primary hover:bg-primary/10">
                {generating ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Sparkles className="h-3.5 w-3.5" />}
                IA
              </Button>
              <Button onClick={() => setPresenting(true)} variant="ghost" size="sm" className="h-8 px-2 gap-1.5 text-xs text-muted-foreground hover:text-foreground">
                <Presentation className="h-3.5 w-3.5" /> Apresentar
              </Button>
              <Button onClick={() => setCreateManualOpen(true)} variant="outline" size="sm" className="h-8 px-3 gap-1.5 text-xs">
                <Plus className="h-3.5 w-3.5" /> Funil manual
              </Button>
              <Button onClick={() => setSaveOpen(true)} size="sm" className="h-8 px-3 gap-1.5 text-xs">
                <Save className="h-3.5 w-3.5" /> Salvar
              </Button>
            </div>
          )}
        </div>

        <TabsContent value="salvos">
          <SavedDiagnosticsList clientId={clientId} clientName={clientName} currencySymbol={currencySymbol} />
        </TabsContent>

        <TabsContent value="atual" className="space-y-6">
          <GoogleAdsSummaryCard clientId={clientId} datePreset={datePreset} currencySymbol={currencySymbol} />
          {activeCampaigns.length === 0 ? (
            <div className="rounded-xl border border-border bg-card p-12 text-center text-muted-foreground text-sm">
              Nenhuma campanha com gasto nos {DATE_LABEL[datePreset] || datePreset}.
            </div>
          ) : (<>
      {/* Compact header — buttons moved next to the tabs above */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-1">
        <div>
          <h2 className="text-base font-bold text-card-foreground">
            Como Estamos — {periodRange}
          </h2>
          <p className="text-[11px] text-muted-foreground">
            {clientName} • {DATE_LABEL[datePreset] || datePreset} • {groups.length} funil(s)/campanha(s) ativos
            {saving && <span className="ml-2 text-primary">• salvando...</span>}
          </p>
        </div>
      </div>

      {/* Documento (vai pro PDF e pra apresentação) */}
      <div ref={docRef} className="space-y-6 mt-6 bg-background p-2">
        {/* Capa */}
        <section className="rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 to-background p-8">
          <p className="text-xs uppercase tracking-widest text-primary font-semibold">Como Estamos — {periodRange}</p>
          <h1 className="text-3xl md:text-4xl font-bold text-card-foreground mt-2">{clientName}</h1>
          <p className="text-sm text-muted-foreground mt-2">
            {DATE_LABEL[datePreset] || datePreset} • {periodRange}
          </p>
        </section>

        {/* Anotações do gestor */}
        <section className="rounded-2xl border border-border bg-card p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-card-foreground">📝 Anotações do gestor</h3>
            <Button onClick={saveNotes} disabled={savingNotes} size="sm" variant="outline" className="gap-2">
              {savingNotes ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Salvar
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-semibold text-card-foreground">
                <ClipboardList className="h-4 w-4 text-primary" /> O que fizemos esta semana
              </div>
              <Textarea
                value={whatWeDid}
                onChange={e => setWhatWeDid(e.target.value)}
                placeholder="Ex: Subimos 3 novos criativos UGC, ajustamos público da campanha X, pausamos conjunto Y..."
                className="min-h-[140px] resize-none"
              />
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-semibold text-card-foreground">
                <ArrowRight className="h-4 w-4 text-primary" /> Próximas ações planejadas
              </div>
              <Textarea
                value={nextActions}
                onChange={e => setNextActions(e.target.value)}
                placeholder="Ex: Escalar criativo X, testar nova oferta Y, gravar UGC Z..."
                className="min-h-[140px] resize-none"
              />
            </div>
          </div>
        </section>

        {/* Funis manuais */}
        {(manualFunnels || []).length > 0 && (
          <section className="space-y-4 rounded-2xl border border-border bg-card p-6">
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div>
                <h3 className="text-lg font-bold text-card-foreground">Funis Manuais</h3>
                <p className="text-xs text-muted-foreground">
                  Os valores editados aqui sincronizam com a aba Análise de Funis.
                </p>
              </div>
              <Button size="sm" variant="outline" className="h-8 gap-1 text-xs" onClick={() => setCreateManualOpen(true)}>
                <Plus className="h-3.5 w-3.5" /> Novo funil manual
              </Button>
            </div>
            <div className="space-y-4">
              {(manualFunnels || []).map((m) => (
                <FunnelPreviewCard
                  key={m.id}
                  clientId={clientId}
                  funnelCode={m.code}
                  funnelLabel={m.label}
                  campaigns={[]}
                  currencySymbol={currencySymbol}
                  datePreset={datePreset}
                  isManual
                  manualId={m.id}
                  onOpenDetail={() => setDetailManual({ code: m.code, label: m.label })}
                />
              ))}
            </div>
          </section>
        )}

        {/* Funis / Campanhas */}
        <div className="space-y-6">
          {groups.map(g => (
            <DiagnosticoFunnelSection
              key={g.key + (g.isFunnel ? "" : "-c")}
              group={g}
              clientId={clientId}
              currencySymbol={currencySymbol}
              datePreset={datePreset}
            />
          ))}
        </div>

        {/* Diagnóstico final em 4 blocos */}
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-card-foreground">🎯 Diagnóstico Final</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <DiagnosticoBloco
              title="O que foi positivo"
              emoji="✅"
              accentClass="border-green-500/30 bg-green-500/5"
              value={blocks.positives}
              onChange={v => updateBlock("positives", v)}
              placeholder="Resultados que melhoraram, criativos vencedores, funis saudáveis..."
            />
            <DiagnosticoBloco
              title="O que foi negativo"
              emoji="⚠️"
              accentClass="border-red-500/30 bg-red-500/5"
              value={blocks.negatives}
              onChange={v => updateBlock("negatives", v)}
              placeholder="Quedas de CTR, CPA alto, criativos com fadiga..."
            />
            <DiagnosticoBloco
              title="Ações do gestor"
              emoji="🛠️"
              accentClass="border-blue-500/30 bg-blue-500/5"
              value={blocks.manager_actions}
              onChange={v => updateBlock("manager_actions", v)}
              placeholder="O que vou executar nos próximos dias para destravar resultados..."
            />
            <DiagnosticoBloco
              title="Pedidos ao cliente"
              emoji="🤝"
              accentClass="border-amber-500/30 bg-amber-500/5"
              value={blocks.client_requests}
              onChange={v => updateBlock("client_requests", v)}
              placeholder="O que precisamos do cliente para destravar (depoimentos, oferta, validação)..."
            />
          </div>
        </section>
      </div>
          </>)}
        </TabsContent>
      </Tabs>

      {presenting && (
        <DiagnosticoPresentMode
          clientName={clientName}
          datePreset={DATE_LABEL[datePreset] || datePreset}
          periodRange={periodRange}
          datePresetKey={datePreset}
          groups={groups}
          manualFunnels={manualFunnels || []}
          blocks={blocks}
          whatWeDid={whatWeDid}
          nextActions={nextActions}
          currencySymbol={currencySymbol}
          onClose={() => setPresenting(false)}
          clientId={clientId}
        />
      )}

      <Dialog open={saveOpen} onOpenChange={setSaveOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Salvar este diagnóstico</DialogTitle>
            <DialogDescription>
              Cria uma versão arquivada do diagnóstico atual ({periodRange}). Você pode revisitá-lo depois na aba "Diagnósticos salvos".
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <label className="text-sm font-medium text-card-foreground">Título</label>
            <Input value={saveTitle} onChange={e => setSaveTitle(e.target.value)} placeholder="Ex: Semana 01–07/05" />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setSaveOpen(false)}>Cancelar</Button>
            <Button onClick={handleSaveSnapshot} disabled={saveDiag.isPending} className="gap-2">
              {saveDiag.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Salvar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {detailManual && (
        <FunnelPremiumDetailDialog
          open={!!detailManual}
          onClose={() => setDetailManual(null)}
          clientId={clientId}
          funnelCode={detailManual.code}
          funnelLabel={detailManual.label}
          campaigns={[]}
          currencySymbol={currencySymbol}
          datePreset={datePreset}
          isManual
        />
      )}

      <Dialog open={createManualOpen} onOpenChange={setCreateManualOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Novo funil manual</DialogTitle>
            <DialogDescription>
              Crie um funil 100% manual para preencher dados como Google Ads e editar métricas no lápis.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="text-xs font-medium text-card-foreground">Código curto</label>
              <Input
                value={newManualCode}
                onChange={(e) => setNewManualCode(e.target.value.toUpperCase())}
                placeholder="GADS"
                maxLength={12}
                className="h-8 text-sm"
              />
              <p className="text-[10px] text-muted-foreground">Identificador único (ex.: GADS, PMAX, SEARCH).</p>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-medium text-card-foreground">Nome de exibição</label>
              <Input
                value={newManualLabel}
                onChange={(e) => setNewManualLabel(e.target.value)}
                placeholder="Google Ads — Performance Max"
                className="h-8 text-sm"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateManualOpen(false)}>Cancelar</Button>
            <Button onClick={handleCreateManual} disabled={createManual.isPending}>Criar funil</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
