import { ArrowDownRight, ArrowUpRight, LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export interface KpiItem {
  label: string;
  value: string;
  delta?: number | null;
  /** Higher-is-better? For deltas, positive shows green; if false, negative is the good one. */
  inverse?: boolean;
  icon?: LucideIcon;
  hint?: string;
  emphasis?: boolean;
  metricKey?: string; // key indicating its data source parameter
}

interface Props {
  items: KpiItem[];
  className?: string;
  onItemClick?: (metricKey: string) => void;
  focusedMetricKey?: string;
}

/**
 * Dense KPI strip used at the top of Visão Geral, Como Estamos and Análise de Funis.
 * Same look across all dashboards — neon green only on the emphasised one.
 */
export function KpiRow({ items, className, onItemClick, focusedMetricKey }: Props) {
  return (
    <div
      className={cn(
        "grid gap-2 sm:gap-3",
        items.length <= 3 && "grid-cols-1 sm:grid-cols-3",
        items.length === 4 && "grid-cols-2 lg:grid-cols-4",
        items.length === 5 && "grid-cols-2 lg:grid-cols-5",
        items.length >= 6 && "grid-cols-2 sm:grid-cols-3 lg:grid-cols-6",
        className,
      )}
    >
      {items.map((it) => {
        const positive = (it.delta ?? 0) >= 0;
        const good = it.inverse ? !positive : positive;
        const Icon = it.icon;
        const clickable = !!(onItemClick && it.metricKey);
        const active = focusedMetricKey === it.metricKey;
        return (
          <div
            key={it.label}
            onClick={() => clickable && onItemClick?.(it.metricKey!)}
            className={cn(
              "group relative rounded-xl border bg-card p-4 shadow-sm hover:shadow-md transition-all duration-200",
              clickable && "cursor-pointer hover:border-primary/50 hover:bg-muted/10",
              active ? "border-[2px] border-primary/90 ring-2 ring-primary/20 shadow-lg" : "border-border"
            )}
            style={clickable ? { contentVisibility: 'auto' } : undefined}
          >
            {clickable && (
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-primary/10 text-primary p-1 rounded-md" title="Configurar fonte de dados (Estilo Looker Studio)">
                <span className="text-[9px] uppercase font-bold tracking-wider mr-1 px-1 py-0.5 bg-primary/20 rounded">Looker</span>
              </div>
            )}
            <div className="flex items-center justify-between gap-2 mb-2">
              <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground truncate">
                {it.label}
              </p>
              {Icon && <Icon className="h-4 w-4 text-muted-foreground/60 shrink-0 group-hover:scale-110 transition-transform" />}
            </div>
            <p
              className={cn(
                "text-2xl sm:text-3xl font-bold tabular-nums tracking-tight truncate",
                it.emphasis ? "text-primary" : "text-card-foreground",
              )}
              title={it.value}
            >
              {it.value}
            </p>
            {it.delta != null && Number.isFinite(it.delta) && (
              <div
                className={cn(
                  "inline-flex items-center gap-0.5 text-[10px] font-semibold mt-1.5 px-1.5 py-0.5 rounded-md",
                  good ? "text-primary bg-primary/10" : "text-destructive bg-destructive/10",
                )}
              >
                {positive ? (
                  <ArrowUpRight className="h-3 w-3" />
                ) : (
                  <ArrowDownRight className="h-3 w-3" />
                )}
                {Math.abs(it.delta).toFixed(1)}%
              </div>
            )}
            {it.hint && (
              <p className="text-[10px] text-muted-foreground/70 mt-1 truncate">{it.hint}</p>
            )}
            {clickable && (
              <div className="text-[9px] text-primary font-medium mt-1.5 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
                <span>⚡ Fonte:</span>
                <span className="text-[8px] bg-primary/5 px-1 py-0.2 rounded border border-primary/20 uppercase">Configurar</span>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}