import { useEffect, useState, useMemo } from "react";
import { 
  Sparkles, 
  Send, 
  Loader2, 
  Settings, 
  Tag, 
  X, 
  Database, 
  SlidersHorizontal, 
  HelpCircle,
  TrendingUp,
  GitCompare,
  Percent,
  CheckCircle2,
  Undo2,
  RefreshCw,
  Plus
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import {
  CONFIGURABLE_METRICS,
  META_FIELDS,
  MetricSource,
  MetricSourcesMap,
  useMetricSources,
  useUpsertMetricSources,
} from "@/hooks/useMetricSources";
import { useDashboardSheet } from "@/hooks/useDashboardSheet";
import { useClients, useUpdateClient } from "@/hooks/useClients";
import { Link } from "react-router-dom";
import { Webhook } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";

const DEFAULT_LEAD_ACTIONS = [
  "lead",
  "onsite_conversion.lead_grouped",
  "onsite_conversion.messaging_conversation_started_7d",
];

const LEAD_ACTION_OPTIONS: { key: string; label: string }[] = [
  { key: "lead", label: "Lead (genérico)" },
  { key: "onsite_conversion.lead_grouped", label: "Lead Forms (Meta)" },
  { key: "onsite_conversion.messaging_conversation_started_7d", label: "Conversa por mensagem" },
  { key: "complete_registration", label: "Cadastro completo" },
  { key: "submit_application", label: "Inscrição enviada" },
  { key: "schedule", label: "Agendamento" },
  { key: "contact", label: "Contato" },
  { key: "subscribe", label: "Inscrição" },
  { key: "initiate_checkout", label: "Iniciou checkout" },
];

interface Props {
  clientId: string;
  open: boolean;
  onOpenChange: (v: boolean) => void;
  /** Pre-selects a metric when opening (optional). */
  focusMetric?: string;
  /** Meta totals for live preview. */
  metaTotals?: Record<string, number>;
  /** Count by raw action_type. */
  actionBreakdown?: Record<string, number>;
}

export function MetricSourceEditor({ 
  clientId, 
  open, 
  onOpenChange, 
  focusMetric, 
  metaTotals, 
  actionBreakdown 
}: Props) {
  const { toast } = useToast();
  const { data: sources, isLoading: isSourcesLoading } = useMetricSources(clientId);
  const { data: sheetCfg } = useDashboardSheet(clientId);
  const { data: clients } = useClients();
  const updateClient = useUpdateClient();
  const client = clients?.find((c) => c.id === clientId);
  const upsert = useUpsertMetricSources();

  // Local Looker Studio state
  const [selectedMetricKey, setSelectedMetricKey] = useState<string>("revenue");
  const [draft, setDraft] = useState<MetricSourcesMap>({});
  const [leadActions, setLeadActions] = useState<string[]>(DEFAULT_LEAD_ACTIONS);
  const [activeTab, setActiveTab] = useState<string>("origem");

  // AI chat states
  const [aiMsg, setAiMsg] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [aiHistory, setAiHistory] = useState<{ role: "user" | "ai"; text: string }[]>([]);

  // Update selected metric and local draft state
  useEffect(() => {
    if (open) {
      setDraft(sources || {});
      if (focusMetric) {
        setSelectedMetricKey(focusMetric);
      } else {
        setSelectedMetricKey("revenue");
      }
    }
  }, [open, sources, focusMetric]);

  useEffect(() => {
    if (open && client) {
      setLeadActions(
        client.lead_action_types && client.lead_action_types.length > 0
          ? client.lead_action_types
          : DEFAULT_LEAD_ACTIONS
      );
    }
  }, [open, client?.id]);

  const sheetColumns = useMemo(() => {
    return Object.values(sheetCfg?.field_mapping || {}).filter(Boolean);
  }, [sheetCfg]);

  const currentMetricSpec = useMemo(() => {
    return CONFIGURABLE_METRICS.find(m => m.key === selectedMetricKey) || CONFIGURABLE_METRICS[0];
  }, [selectedMetricKey]);

  const currentMetricConfig = useMemo(() => {
    return draft[selectedMetricKey] || { source: "sheets" as const };
  }, [draft, selectedMetricKey]);

  // Save specific parameter to the draft map
  const setMetricConfig = (patch: Partial<MetricSourcesMap[string]>) => {
    setDraft((prev) => ({
      ...prev,
      [selectedMetricKey]: {
        source: "sheets",
        ...prev[selectedMetricKey],
        ...patch,
      } as any,
    }));
  };

  const handleSaveAll = async () => {
    try {
      await upsert.mutateAsync({ clientId, sources: draft });
      
      const current = client?.lead_action_types || DEFAULT_LEAD_ACTIONS;
      const sameSet = current.length === leadActions.length && current.every((c) => leadActions.includes(c));
      if (!sameSet) {
        await updateClient.mutateAsync({ id: clientId, lead_action_types: leadActions } as any);
      }
      
      toast({ title: "Visual persistido com sucesso!", description: "Sua fonte de dados Looker Studio foi salva." });
      onOpenChange(false);
    } catch (e: any) {
      toast({ title: "Erro ao salvar", description: e.message, variant: "destructive" });
    }
  };

  const handleAiSend = async () => {
    if (!aiMsg.trim()) return;
    const userMsg = aiMsg.trim();
    setAiMsg("");
    setAiHistory((h) => [...h, { role: "user", text: userMsg }]);
    setAiLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("metric-source-ai", {
        body: {
          message: userMsg,
          currentSources: draft,
          availableMetrics: CONFIGURABLE_METRICS.map((m) => m.key),
          sheetColumns,
        },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      if (data?.sources) {
        setDraft(data.sources);
        if (data.updatedMetric && CONFIGURABLE_METRICS.some(m => m.key === data.updatedMetric)) {
          setSelectedMetricKey(data.updatedMetric);
        }
        setAiHistory((h) => [
          ...h,
          { role: "ai", text: data.explanation || `Configuração de dados atualizada para o Copiloto.` }
        ]);
      }
    } catch (e: any) {
      setAiHistory((h) => [...h, { role: "ai", text: `Recurso de IA temporariamente indisponível. Detalhes: ${e.message}` }]);
    } finally {
      setAiLoading(false);
    }
  };

  // Safe client-side math simulation preview
  const livePreviewValue = useMemo(() => {
    const cfg = currentMetricConfig;
    if (!cfg) return "0";

    const getPrimaryValue = (src: MetricSource, f?: string, val?: number) => {
      if (src === "manual") return val ?? 0;
      if (src === "meta" && f) return metaTotals?.[f] ?? 0;
      if (src === "webhook" && f) return f === "revenue" ? 42000 : f === "sales" ? 140 : 300; // Simulated preview fallback
      return 1500; // Sheets default preview simulation
    };

    let val = getPrimaryValue(cfg.source, cfg.field, cfg.value);

    // Advanced blending math
    if (cfg.blendOperator && cfg.blendSource) {
      const bVal = getPrimaryValue(cfg.blendSource, cfg.blendField, cfg.blendValue);
      switch (cfg.blendOperator) {
        case "+": val += bVal; break;
        case "-": val -= bVal; break;
        case "*": val *= bVal; break;
        case "/": val = bVal !== 0 ? val / bVal : 0; break;
      }
    }

    if (cfg.multiplier !== undefined) {
      val *= Number(cfg.multiplier);
    }
    if (cfg.offset !== undefined) {
      val += Number(cfg.offset);
    }

    return Number(val).toLocaleString("pt-BR", { maximumFractionDigits: 1 });
  }, [currentMetricConfig, metaTotals]);

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Dark backdrop backdrop overlay */}
          <div 
            key="metric-source-editor-backdrop"
            className="fixed inset-0 bg-background/60 backdrop-blur-sm z-50 transition-opacity duration-300"
            onClick={() => onOpenChange(false)}
          />

          {/* Looker Studio Inspector sliding panel container */}
          <motion.div
            key="metric-source-editor-panel"
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 220 }}
            className="fixed top-0 right-0 h-full w-[460px] bg-card border-l border-border shadow-2xl z-50 flex flex-col focus:outline-none"
          >
        {/* Sleek Looker Studio Branding Header */}
        <div className="p-5 border-b border-border bg-slate-900/40 relative">
          <Button
            size="icon"
            variant="ghost"
            onClick={() => onOpenChange(false)}
            className="absolute top-4 right-4 h-8 w-8 hover:bg-muted text-muted-foreground/80 hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </Button>
          
          <div className="flex items-center gap-2 mb-1">
            <div className="h-5 w-5 rounded bg-primary/20 flex items-center justify-center border border-primary/40">
              <Database className="h-3 w-3 text-primary" />
            </div>
            <span className="text-[10px] font-bold text-primary uppercase tracking-widest bg-primary/10 px-1.5 py-0.5 rounded">Looker Studio Dynamic inspector</span>
          </div>
          <h3 className="text-base font-bold text-foreground">Editor de Fontes & Métricas</h3>
          <p className="text-xs text-muted-foreground mt-0.5">Altere, combine e mescle dados para o elemento selecionado.</p>
        </div>

        {/* Global Metric Switcher Dropdown (just like Looker Studio editor selector) */}
        <div className="px-5 py-4 border-b border-border bg-muted/20 flex flex-col gap-1.5">
          <Label className="text-[11px] uppercase tracking-wider font-semibold text-muted-foreground">Elemento / Métrica Selecionada</Label>
          <div className="flex gap-2 items-center">
            <Select 
              value={selectedMetricKey} 
              onValueChange={setSelectedMetricKey}
            >
              <SelectTrigger className="flex-1 bg-background border-border text-xs h-9">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CONFIGURABLE_METRICS.map((item) => (
                  <SelectItem key={item.key} value={item.key} className="text-xs">
                    {item.label} <span className="text-[9px] text-muted-foreground">({item.group})</span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="text-[10px] font-mono bg-muted border border-border px-2 py-1.5 rounded text-muted-foreground shrink-0 uppercase tracking-wide">
              ID: {currentMetricSpec.key}
            </div>
          </div>
        </div>

        {/* Live Calculation Output Indicator Card */}
        <div className="mx-5 my-4 p-4 rounded-xl border border-primary/20 bg-primary/5 shadow-inner relative overflow-hidden flex flex-col">
          <div className="flex justify-between items-start mb-2">
            <div>
              <span className="text-[10px] font-bold text-primary uppercase tracking-wider">Preview de Cálculo</span>
              <p className="text-xs text-muted-foreground">Simulação com a fórmula atualizada:</p>
            </div>
            <span className="text-[10px] bg-muted border border-border rounded px-1.5 py-0.5 font-mono text-muted-foreground uppercase">{currentMetricConfig.source}</span>
          </div>
          <div className="text-3xl font-black text-foreground tracking-tight select-all">
            {livePreviewValue}
          </div>
          <p className="text-[9px] text-muted-foreground/80 mt-1">
            * Valores calculados com base no período atual selecionado no cabeçalho do dashboard.
          </p>
        </div>

        {/* Studio Control Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 overflow-hidden flex flex-col px-5">
          <TabsList className="grid grid-cols-3 bg-muted/40 p-1 border border-border/80 h-9 shrink-0 gap-1 rounded-lg">
            <TabsTrigger value="origem" className="text-xs gap-1 py-1 data-[state=active]:bg-background">
              <Database className="h-3 w-3" /> 1. Origem
            </TabsTrigger>
            <TabsTrigger value="blend" className="text-xs gap-1 py-1 data-[state=active]:bg-background">
              <SlidersHorizontal className="h-3 w-3" /> 2. Combinação
            </TabsTrigger>
            <TabsTrigger value="ai" className="text-xs gap-1 py-1 data-[state=active]:bg-background">
              <Sparkles className="h-3 w-3" /> 3. Copiloto IA
            </TabsTrigger>
          </TabsList>

          {/* 1. DATA SOURCE SETUP CONTENT */}
          <TabsContent value="origem" className="flex-1 overflow-y-auto pt-4 space-y-4 pr-1">
            <div className="space-y-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-semibold text-foreground flex items-center justify-between">
                  <span>Origem Principal dos Dados</span>
                  <HelpCircle className="h-3 w-3 text-muted-foreground/60 cursor-help" title="De onde este KPI vai puxar os dados principais" />
                </Label>
                <Select
                  value={currentMetricConfig.source}
                  onValueChange={(v) => setMetricConfig({ source: v as any, field: undefined, value: undefined })}
                >
                  <SelectTrigger className="bg-background h-8 text-xs border-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sheets">📊 Planilha Google Sheets</SelectItem>
                    <SelectItem value="meta">🌐 Meta Ads API Integration</SelectItem>
                    <SelectItem value="webhook">🔌 Webhook Integrator (Eduzz, Hotmart, Kiwify)</SelectItem>
                    <SelectItem value="manual">✏️ Entrada Manual / Constante</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-[11px] text-muted-foreground">Configura de onde vem a fonte principal de entrada de dados.</p>
              </div>

              {/* SHEET FIELD SOURCE MAP */}
              {currentMetricConfig.source === "sheets" && (
                <div className="p-3 bg-muted/30 border border-border/60 rounded-lg space-y-2.5">
                  <Label className="text-xs font-semibold text-foreground">Coluna Mapeada da Planilha</Label>
                  <Select 
                    value={currentMetricConfig.field || ""} 
                    onValueChange={(v) => setMetricConfig({ field: v })}
                  >
                    <SelectTrigger className="bg-background h-8 text-xs border-border/80">
                      <SelectValue placeholder="Selecione a coluna desejada..." />
                    </SelectTrigger>
                    <SelectContent>
                      {sheetColumns.length === 0 ? (
                        <SelectItem value="__none" disabled>Nenhuma coluna importada</SelectItem>
                      ) : (
                        sheetColumns.map((col) => (
                          <SelectItem key={col} value={col} className="text-xs">{col}</SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                  <p className="text-[10px] text-muted-foreground">
                    Os dados são importados automaticamente baseados na sincronização mapeada nas configurações gerais de abas e colunas.
                  </p>
                </div>
              )}

              {/* MANUAL CONSTANT SOURCE MAP */}
              {currentMetricConfig.source === "manual" && (
                <div className="p-3 bg-muted/30 border border-border/60 rounded-lg space-y-2.5">
                  <Label className="text-xs font-semibold text-foreground">Valor Fixo Override</Label>
                  <div className="flex gap-2">
                    <Input
                      type="number"
                      value={currentMetricConfig.value ?? ""}
                      placeholder="Ex: 5000"
                      onChange={(e) => setMetricConfig({ value: Number(e.target.value) })}
                      className="bg-background h-8 text-xs"
                    />
                  </div>
                  <p className="text-[10px] text-muted-foreground">
                    Uma constante numérica que substitui qualquer chamada dinâmica externa. Ideal para testes ou metas manuais.
                  </p>
                </div>
              )}

              {/* WEBHOOK SOURCE MAP */}
              {currentMetricConfig.source === "webhook" && (
                <div className="p-3 bg-muted/30 border border-border/60 rounded-lg space-y-3">
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-foreground">Agregado de Vendas</Label>
                    <Select 
                      value={currentMetricConfig.field || ""} 
                      onValueChange={(v) => setMetricConfig({ field: v })}
                    >
                      <SelectTrigger className="bg-background h-8 text-xs border-border/80">
                        <SelectValue placeholder="Selecione o agregado..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="revenue">Faturamento de Vendas (soma total)</SelectItem>
                        <SelectItem value="sales">Vendas Realizadas (contagem total)</SelectItem>
                        <SelectItem value="avg_ticket">Ticket Médio das Transações</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="p-2 border border-blue-500/10 bg-blue-500/5 rounded text-[11px] leading-relaxed text-blue-200">
                    <p className="font-semibold flex items-center gap-1"><Webhook className="h-3.5 w-3.5" /> Integração de Webhooks ativa</p>
                    <p className="mt-1">
                      As vendas vindas de plataformas como Kiwify, Hotmart de forma em tempo real serão automaticamente agregadas a esta escolha.
                    </p>
                  </div>
                  <Link
                    onClick={() => onOpenChange(false)}
                    to={`/clients/${clientId}/webhooks`}
                    className="inline-flex items-center gap-1 text-[11px] text-primary hover:underline font-semibold"
                  >
                    ➡️ Ir para configuração detalhada de webhooks
                  </Link>
                </div>
              )}

              {/* META ADS FIELD SOURCE MAP */}
              {currentMetricConfig.source === "meta" && (
                <div className="p-3 bg-muted/30 border border-border/60 rounded-lg space-y-3">
                  <div className="space-y-1">
                    <Label className="text-xs font-semibold text-foreground">Campo nativo do Meta Ads API</Label>
                    <Select 
                      value={currentMetricConfig.field || ""} 
                      onValueChange={(v) => setMetricConfig({ field: v })}
                    >
                      <SelectTrigger className="bg-background h-8 text-xs border-border">
                        <SelectValue placeholder="Escolha a métrica da campanha..." />
                      </SelectTrigger>
                      <SelectContent>
                        {META_FIELDS.map((f) => (
                          <SelectItem key={f.key} value={f.key} className="text-xs">
                            {f.label} {metaTotals && metaTotals[f.key] !== undefined && `(${Number(metaTotals[f.key]).toLocaleString("pt-BR")})`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {currentMetricConfig.field === "lead_actions" && (
                    <div className="p-2 border border-border rounded bg-card space-y-2">
                      <Label className="text-[11px] font-semibold text-foreground flex items-center gap-1.5">
                        <Tag className="h-3 w-3 text-primary" /> Ações do pixel classificadas como Leads
                      </Label>
                      <div className="grid grid-cols-1 gap-1 max-h-[160px] overflow-y-auto pr-1">
                        {LEAD_ACTION_OPTIONS.map((opt) => {
                          const checked = leadActions.includes(opt.key);
                          const count = actionBreakdown?.[opt.key];
                          return (
                            <label
                              key={opt.key}
                              className="flex items-center justify-between gap-1.5 text-[11px] hover:bg-muted/40 p-1.5 rounded cursor-pointer transition-colors border border-border/45"
                            >
                              <div className="flex items-center gap-2">
                                <Checkbox
                                  checked={checked}
                                  onCheckedChange={(v) => {
                                    if (v) setLeadActions((arr) => Array.from(new Set([...arr, opt.key])));
                                    else setLeadActions((arr) => arr.filter((k) => k !== opt.key));
                                  }}
                                />
                                <span className="font-medium">{opt.label}</span>
                              </div>
                              {count !== undefined && (
                                <span className="text-[10px] text-muted-foreground bg-muted px-1.5 py-0.2 rounded font-mono">
                                  {count}
                                </span>
                              )}
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </TabsContent>

          {/* 2. ADVANCED DATA BLENDING SETUP CONTENT */}
          <TabsContent value="blend" className="flex-1 overflow-y-auto pt-4 space-y-4 pr-1">
            <div className="space-y-4">
              <div className="p-3 bg-primary/5 border border-primary/20 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <GitCompare className="h-4 w-4 text-primary" />
                    <Label className="text-xs font-bold text-foreground">Data Blending (Fórmula Integrada)</Label>
                  </div>
                  <Checkbox 
                    checked={!!currentMetricConfig.blendOperator}
                    onCheckedChange={(checked) => {
                      if (checked) {
                        setMetricConfig({
                          blendOperator: "+",
                          blendSource: "sheets",
                        });
                      } else {
                        setMetricConfig({
                          blendOperator: undefined,
                          blendSource: undefined,
                          blendField: undefined,
                          blendValue: undefined,
                        });
                      }
                    }}
                  />
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  Mescle dados da fonte principal com outra de canal alternativo (ex: Investimento Meta Ads + Investimento Google Ads de faturamento).
                </p>

                {currentMetricConfig.blendOperator && (
                  <div className="pt-3 border-t border-border/40 space-y-3">
                    <div className="grid grid-cols-3 gap-2 items-center">
                      <div className="col-span-1 text-center text-xs font-bold font-mono bg-background border rounded py-1 border-primary/20">
                        {currentMetricConfig.source?.toUpperCase()}
                      </div>
                      
                      <div className="col-span-1">
                        <Select
                          value={currentMetricConfig.blendOperator}
                          onValueChange={(op: any) => setMetricConfig({ blendOperator: op })}
                        >
                          <SelectTrigger className="h-8 bg-background text-xs text-center justify-center font-bold">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="+">➕ ADIÇÃO (+)</SelectItem>
                            <SelectItem value="-">➖ SUBTRAÇÃO (-)</SelectItem>
                            <SelectItem value="*">✖️ PRODUTO (*)</SelectItem>
                            <SelectItem value="/">➗ DIVISÃO (/)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="col-span-1">
                        <Select
                          value={currentMetricConfig.blendSource}
                          onValueChange={(src: any) => setMetricConfig({ blendSource: src, blendField: undefined, blendValue: undefined })}
                        >
                          <SelectTrigger className="h-8 bg-background text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="sheets">Planilha</SelectItem>
                            <SelectItem value="meta">Meta Ads</SelectItem>
                            <SelectItem value="webhook">Webhook</SelectItem>
                            <SelectItem value="manual">Manual</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Blend child values map */}
                    {currentMetricConfig.blendSource === "sheets" && (
                      <div className="space-y-1">
                        <Label className="text-[10px] uppercase text-muted-foreground font-semibold">Coluna da Planilha para Combinar</Label>
                        <Select 
                          value={currentMetricConfig.blendField || ""} 
                          onValueChange={(v) => setMetricConfig({ blendField: v })}
                        >
                          <SelectTrigger className="bg-background h-8 text-xs border-border">
                            <SelectValue placeholder="Selecione a coluna..." />
                          </SelectTrigger>
                          <SelectContent>
                            {sheetColumns.map((col) => (
                              <SelectItem key={col} value={col} className="text-xs">{col}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    {currentMetricConfig.blendSource === "meta" && (
                      <div className="space-y-1">
                        <Label className="text-[10px] uppercase text-muted-foreground font-semibold">Campo do Meta para Combinar</Label>
                        <Select 
                          value={currentMetricConfig.blendField || ""} 
                          onValueChange={(v) => setMetricConfig({ blendField: v })}
                        >
                          <SelectTrigger className="bg-background h-8 text-xs border-border">
                            <SelectValue placeholder="Escolha a métrica..." />
                          </SelectTrigger>
                          <SelectContent>
                            {META_FIELDS.map((f) => (
                              <SelectItem key={f.key} value={f.key} className="text-xs">{f.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    )}

                    {currentMetricConfig.blendSource === "manual" && (
                      <div className="space-y-1">
                        <Label className="text-[10px] uppercase text-muted-foreground font-semibold">Valor constante secundário</Label>
                        <Input
                          type="number"
                          value={currentMetricConfig.blendValue ?? ""}
                          placeholder="Valor constante"
                          onChange={(e) => setMetricConfig({ blendValue: Number(e.target.value) })}
                          className="bg-background h-8 text-xs"
                        />
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* FACTOR COEFFICIENTS SECTION */}
              <div className="p-3 bg-muted/40 border border-border/80 rounded-xl space-y-3">
                <div className="flex items-center gap-1.5">
                  <SlidersHorizontal className="h-4 w-4 text-muted-foreground" />
                  <Label className="text-xs font-bold text-foreground">Fatores de Correção & Ajustes</Label>
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label className="text-[11px] text-muted-foreground">Multiplicador (Fator K)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="Ex: 1.15"
                      value={currentMetricConfig.multiplier ?? ""}
                      onChange={(e) => {
                        const val = e.target.value === "" ? undefined : Number(e.target.value);
                        setMetricConfig({ multiplier: val });
                      }}
                      className="bg-background h-8 text-xs border-border/70"
                    />
                    <p className="text-[9px] text-muted-foreground/80 leading-tight">Aumenta ou reduz o total proporcionalmente (ex: 1.1 = +10%).</p>
                  </div>

                  <div className="space-y-1.5">
                    <Label className="text-[11px] text-muted-foreground">Adição Fixa (Offset)</Label>
                    <Input
                      type="number"
                      placeholder="Ex: +50"
                      value={currentMetricConfig.offset ?? ""}
                      onChange={(e) => {
                        const val = e.target.value === "" ? undefined : Number(e.target.value);
                        setMetricConfig({ offset: val });
                      }}
                      className="bg-background h-8 text-xs border-border/70"
                    />
                    <p className="text-[9px] text-muted-foreground/80 leading-tight">Soma ou subtrai um valor absoluto fixo ao final.</p>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* 3. COPILOTO IA TAB CONTENT */}
          <TabsContent value="ai" className="flex-1 overflow-hidden flex flex-col pt-3">
            <div className="flex-1 overflow-y-auto space-y-2 p-3 bg-muted/30 border border-border/60 rounded-xl min-h-[220px]">
              {aiHistory.length === 0 && (
                <div className="text-center py-6 px-4 space-y-2">
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                    <Sparkles className="h-4 w-4 text-primary" />
                  </div>
                  <p className="text-xs font-semibold text-foreground">Copiloto Inteligente de Fontes</p>
                  <p className="text-[11px] text-muted-foreground leading-relaxed">
                    Diga em linguagem natural o que deseja reconfigurar neste elemento.
                  </p>
                  <div className="pt-2 text-left space-y-1">
                    <p className="text-[10px] font-mono text-muted-foreground bg-background p-1.5 border border-border/40 rounded italic cursor-pointer hover:bg-muted" onClick={() => setAiMsg("Quero que esta métrica seja manual com valor fixo de 25000")}>
                      "Faturamento como manual com valor de 25000"
                    </p>
                    <p className="text-[10px] font-mono text-muted-foreground bg-background p-1.5 border border-border/40 rounded italic cursor-pointer hover:bg-muted" onClick={() => setAiMsg("Faça com que este elemento combine a coluna Receita do sheets somada com o investimento de anúncios")}>
                      "Soma a coluna Receita com o Meta Ads"
                    </p>
                  </div>
                </div>
              )}
              {aiHistory.map((m, i) => (
                <div
                  key={i}
                  className={`text-xs p-2.5 rounded-lg border leading-relaxed ${
                    m.role === "user" 
                      ? "bg-primary/5 border-primary/20 ml-6 text-foreground" 
                      : "bg-card border-border mr-6 text-muted-foreground"
                  }`}
                >
                  <div className="text-[10px] font-bold uppercase tracking-wider mb-0.5 text-foreground flex items-center gap-1">
                    {m.role === "user" ? <span className="text-primary">Você</span> : <span className="text-foreground flex items-center gap-1"><Sparkles className="h-3 w-3 text-primary animate-pulse" /> Copiloto</span>}
                  </div>
                  {m.text}
                </div>
              ))}
              {aiLoading && (
                <div className="flex items-center gap-2 text-xs text-muted-foreground p-2">
                  <Loader2 className="h-3 w-3 animate-spin text-primary" /> pensando na melhor fórmula...
                </div>
              )}
            </div>
            
            <div className="flex gap-1.5 mt-3">
              <Input
                value={aiMsg}
                onChange={(e) => setAiMsg(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && !aiLoading && handleAiSend()}
                placeholder="Ex: multiplique esta métrica por 1.2"
                className="text-xs bg-background h-8"
              />
              <Button onClick={handleAiSend} disabled={aiLoading || !aiMsg.trim()} size="sm" className="h-8 px-2.5 shrink-0 bg-primary hover:bg-primary/95 text-primary-foreground font-semibold">
                <Send className="h-3.5 w-3.5" />
              </Button>
            </div>
            <p className="text-[9px] text-muted-foreground mt-1 text-center">
              A IA reconfigura as caixas de seleção em tempo real sem afetar os dados de produção até que você clique em Aplicar.
            </p>
          </TabsContent>
        </Tabs>

        {/* Action Panel Footer controls */}
        <div className="p-5 border-t border-border bg-slate-900/10 flex gap-2 shrink-0">
          <Button 
            variant="ghost" 
            onClick={() => onOpenChange(false)} 
            className="flex-1 text-xs border border-border/80 hover:bg-muted"
          >
            Cancelar
          </Button>
          <Button 
            onClick={handleSaveAll} 
            disabled={upsert.isPending}
            className="flex-1 text-xs bg-primary hover:bg-primary/95 text-primary-foreground font-semibold"
          >
            {upsert.isPending ? (
              <span className="flex items-center gap-1.5 justify-center">
                <Loader2 className="h-3.5 w-3.5 animate-spin" /> Aplicando...
              </span>
            ) : (
              <span className="flex items-center gap-1 justify-center">
                <CheckCircle2 className="h-3.5 w-3.5" /> Aplicar na Métrica
              </span>
            )}
          </Button>
        </div>
      </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
