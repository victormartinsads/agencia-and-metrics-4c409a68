import { ReactNode } from "react";
import { ArrowDown, ArrowUp, EyeOff, Settings2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

interface Props {
  title?: string;
  children: ReactNode;
  className?: string;
  compact?: boolean;
  /** Editor controls (rendered only when editMode is true). */
  editMode?: boolean;
  onMoveUp?: () => void;
  onMoveDown?: () => void;
  onHide?: () => void;
  onConfigure?: () => void;
}

export function SectionCard({
  title,
  children,
  className,
  compact,
  editMode,
  onMoveUp,
  onMoveDown,
  onHide,
  onConfigure,
}: Props) {
  return (
    <div
      className={cn(
        "relative rounded-xl bg-card border border-border shadow-sm overflow-hidden h-full flex flex-col transition-shadow hover:shadow-md",
        editMode && "ring-2 ring-primary/50",
        compact ? "p-3" : "p-4",
        className,
      )}
    >
      {(title || editMode) && (
        <div className="flex items-center justify-between gap-3 mb-3 border-b border-border/50 pb-2">
          {title ? (
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              {title}
            </h3>
          ) : (
            <span />
          )}
          {editMode && (
            <div className="flex items-center gap-1">
              {onConfigure && (
                <Button variant="ghost" size="icon" className="h-7 w-7 hover:text-primary" onClick={onConfigure} title="Configurar">
                  <Settings2 className="h-3.5 w-3.5" />
                </Button>
              )}
              {onMoveUp && (
                <Button variant="ghost" size="icon" className="h-7 w-7 hover:text-primary" onClick={onMoveUp} title="Mover para cima">
                  <ArrowUp className="h-3.5 w-3.5" />
                </Button>
              )}
              {onMoveDown && (
                <Button variant="ghost" size="icon" className="h-7 w-7 hover:text-primary" onClick={onMoveDown} title="Mover para baixo">
                  <ArrowDown className="h-3.5 w-3.5" />
                </Button>
              )}
              {onHide && (
                <Button variant="ghost" size="icon" className="h-7 w-7 hover:text-destructive" onClick={onHide} title="Ocultar bloco">
                  <EyeOff className="h-3.5 w-3.5" />
                </Button>
              )}
            </div>
          )}
        </div>
      )}
      <div className="flex-1 min-h-0 overflow-hidden">{children}</div>
    </div>
  );
}