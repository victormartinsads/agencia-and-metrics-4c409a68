import { ArrowUpRight, ArrowDownRight, Minus } from "lucide-react";

interface Props {
  label: string;
  value: string;
  delta?: number | null;
  sub?: string;
  inverse?: boolean;
  emphasis?: boolean;
  icon?: React.ReactNode;
  onClick?: () => void;
  active?: boolean;
}

export function KpiCardPremium({ label, value, delta, sub, inverse, emphasis, icon, onClick, active }: Props) {
  const isPos = delta != null && delta > 0.1;
  const isNeg = delta != null && delta < -0.1;
  const goodUp = !inverse;
  const tone = delta == null
    ? "neu"
    : (isPos && goodUp) || (isNeg && !goodUp) ? "up"
    : (isNeg && goodUp) || (isPos && !goodUp) ? "dn"
    : "neu";
  const clickable = !!onClick;
  return (
    <div 
      onClick={onClick}
      className={`relative overflow-hidden rounded-xl bg-card border px-4 pt-4 pb-3 shadow-sm transition-all duration-200 ${
        clickable ? "cursor-pointer hover:border-primary/50 hover:bg-muted/10" : ""
      } ${
        active ? "border-[2px] border-primary ring-2 ring-primary/20 shadow-lg" : "border-border hover:shadow-md"
      }`}
    >
      {clickable && (
        <span className="absolute top-1.5 right-1.5 opacity-0 group-hover:opacity-100 transition-opacity text-[8px] bg-primary/20 text-primary font-bold px-1 rounded">Looker</span>
      )}
      <div className="flex items-center justify-between text-[10px] uppercase tracking-wider font-semibold text-muted-foreground mb-2">
        <span>{label}</span>
        {icon && <span className="text-muted-foreground/50">{icon}</span>}
      </div>
      <div
        className={`text-2xl leading-none font-bold tracking-tight mb-2 ${
          emphasis ? "text-primary" : "text-foreground"
        }`}
      >
        {value}
      </div>
      <div className="flex items-center gap-1.5">
        {delta != null && (
          <span className={`inline-flex items-center gap-0.5 text-[10px] font-bold ${
            tone === "up" ? "text-primary" : tone === "dn" ? "text-destructive" : "text-muted-foreground"
          }`}>
            {tone === "up" ? <ArrowUpRight className="h-3 w-3" /> : tone === "dn" ? <ArrowDownRight className="h-3 w-3" /> : <Minus className="h-3 w-3" />}
            {Math.abs(delta).toFixed(1)}%
          </span>
        )}
        {sub && <span className="text-[10px] text-muted-foreground/70">{sub}</span>}
      </div>
    </div>
  );
}