import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useUpsertCreativeOverride, CreativeOverride } from "@/hooks/useCreativeOverrides";
import { toast } from "sonner";
import { Save, RotateCcw } from "lucide-react";

interface MetricField {
  key: string;
  label: string;
  original: number;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  clientId: string;
  creativeId: string;
  creativeName: string;
  metrics: MetricField[];
  existingOverrides: CreativeOverride[];
}

export function CreativeEditModal({ open, onOpenChange, clientId, creativeId, creativeName, metrics, existingOverrides }: Props) {
  const upsert = useUpsertCreativeOverride();

  const getOverrideValue = (key: string, original: number) => {
    const ov = existingOverrides.find(o => o.creative_id === creativeId && o.metric_name === key);
    return ov ? ov.metric_value : original;
  };

  const [values, setValues] = useState<Record<string, string>>(() => {
    const init: Record<string, string> = {};
    for (const m of metrics) {
      init[m.key] = String(getOverrideValue(m.key, m.original));
    }
    return init;
  });

  const handleSave = async () => {
    try {
      for (const m of metrics) {
        const num = parseFloat(values[m.key]);
        if (isNaN(num)) continue;
        if (num !== m.original) {
          await upsert.mutateAsync({
            client_id: clientId,
            creative_id: creativeId,
            metric_name: m.key,
            metric_value: num,
          });
        }
      }
      toast.success("Métricas atualizadas!");
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e.message || "Erro ao salvar");
    }
  };

  const handleReset = (key: string, original: number) => {
    setValues(prev => ({ ...prev, [key]: String(original) }));
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-sm">Editar Métricas — {creativeName}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3 mt-2">
          {metrics.map((m) => (
            <div key={m.key} className="space-y-1">
              <Label className="text-xs flex items-center justify-between">
                <span>{m.label}</span>
                <button
                  type="button"
                  onClick={() => handleReset(m.key, m.original)}
                  className="text-[10px] text-muted-foreground hover:text-foreground flex items-center gap-1"
                >
                  <RotateCcw className="h-3 w-3" /> Original: {m.original.toLocaleString("pt-BR", { maximumFractionDigits: 2 })}
                </button>
              </Label>
              <Input
                type="number"
                step="any"
                value={values[m.key]}
                onChange={(e) => setValues(prev => ({ ...prev, [m.key]: e.target.value }))}
                className="h-8 text-sm"
              />
            </div>
          ))}
          <Button onClick={handleSave} disabled={upsert.isPending} className="w-full mt-2" size="sm">
            <Save className="h-3.5 w-3.5 mr-1" /> Salvar Alterações
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
