import { Pencil, LayoutTemplate, Database, CalendarRange } from "lucide-react";
import { useMemo, useState } from "react";
import { format, startOfWeek, endOfWeek, startOfMonth, endOfMonth, subDays } from "date-fns";
import { ptBR } from "date-fns/locale";
import { cn } from "@/lib/utils";
import { DateRangePicker } from "@/components/ui/date-range-picker";
import { toast } from "sonner";

export interface DashboardTab {
  id: string;
  label: string;
}

interface Props {
  tabs: DashboardTab[];
  activeTab: string;
  onTabChange: (id: string) => void;
  datePreset: string;
  onDatePresetChange: (v: string) => void;
  compareEnabled?: boolean;
  onToggleCompare?: () => void;
  onEdit?: () => void;
  onTemplate?: () => void;
  onSources?: () => void;
  clientName?: string;
  clientLogoUrl?: string | null;
  rightExtra?: React.ReactNode;
}

function fmtPreset(value: string): string {
  // Try parse custom range
  const m = /^custom:(\d{4}-\d{2}-\d{2}):(\d{4}-\d{2}-\d{2})$/.exec(value);
  if (m) {
    const from = new Date(m[1] + "T00:00:00");
    const to = new Date(m[2] + "T00:00:00");
    const sameMonth = from.getMonth() === to.getMonth();
    if (sameMonth) {
      return `${format(from, "dd")} – ${format(to, "dd MMM", { locale: ptBR })}`;
    }
    return `${format(from, "dd MMM", { locale: ptBR })} – ${format(to, "dd MMM", { locale: ptBR })}`;
  }
  const today = new Date();
  if (value === "today") return format(today, "dd MMM", { locale: ptBR });
  if (value === "yesterday") return format(subDays(today, 1), "dd MMM", { locale: ptBR });
  if (value === "last_7d") {
    const from = subDays(today, 6);
    return `${format(from, "dd")} – ${format(today, "dd MMM", { locale: ptBR })}`;
  }
  if (value === "last_14d") return "Últimos 14d";
  if (value === "last_30d") return "Últimos 30d";
  if (value === "this_month") return format(today, "MMMM", { locale: ptBR });
  if (value === "last_month") return "Mês passado";
  return "Período";
}

export function DashboardTopBar({
  tabs, activeTab, onTabChange,
  datePreset, onDatePresetChange,
  compareEnabled = false, onToggleCompare,
  onEdit, onTemplate, onSources,
  clientName, clientLogoUrl, rightExtra,
}: Props) {
  const [customOpen, setCustomOpen] = useState(false);

  const presetIsWeek = datePreset === "last_7d";
  const presetIsMonth = datePreset === "this_month";
  const presetIsCustom = datePreset.startsWith("custom:") || (!presetIsWeek && !presetIsMonth);

  const currentChipLabel = fmtPreset(datePreset);

  return (
    <div className="bg-background border-b border-border/60">
      {/* Row 1 — logo + nav + actions */}
      <div className="h-[68px] flex items-center gap-6 px-5">
        {/* Client identity */}
        <div className="flex items-center gap-2.5 shrink-0 min-w-0 max-w-[260px]">
          {clientLogoUrl ? (
            <img
              src={clientLogoUrl}
              alt={clientName || "Cliente"}
              className="h-8 w-8 rounded-full object-cover bg-black border border-border shrink-0"
            />
          ) : (
            <span className="grid h-8 w-8 place-items-center rounded-full bg-muted border border-border shrink-0">
              <span className="text-xs font-bold text-muted-foreground tracking-wide">
                {(clientName || "·").split(" ").map((w) => w[0]).join("").slice(0, 2).toUpperCase()}
              </span>
            </span>
          )}
          {clientName && (
            <span
              className="text-sm font-semibold text-foreground truncate"
              title={clientName}
            >
              {clientName}
            </span>
          )}
        </div>

        {/* Tabs */}
        <nav
          className="flex-1 flex items-center gap-1 overflow-x-auto"
          style={{ scrollbarWidth: "none" }}
        >
          {tabs.map((t) => {
            const active = t.id === activeTab;
            return (
              <button
                key={t.id}
                onClick={() => onTabChange(t.id)}
                className={cn(
                  "relative h-[68px] px-4 text-sm whitespace-nowrap transition-colors",
                  active
                    ? "text-primary font-medium"
                    : "text-muted-foreground hover:text-foreground font-normal",
                )}
              >
                {t.label}
                {active && (
                  <span className="absolute left-4 right-4 bottom-0 h-0.5 rounded-t-full bg-primary" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => (onTemplate ? onTemplate() : toast.info("Templates de layout em breve"))}
            className="h-9 px-3 rounded-lg border border-border bg-transparent hover:bg-muted text-xs font-medium text-foreground flex items-center gap-1.5 transition-colors"
          >
            <LayoutTemplate className="h-3.5 w-3.5" /> Template
          </button>
          <button
            onClick={() => (onSources ? onSources() : toast.info("Fontes de dados em breve"))}
            className="h-9 px-3 rounded-lg border border-border bg-transparent hover:bg-muted text-xs font-medium text-foreground flex items-center gap-1.5 transition-colors"
          >
            <Database className="h-3.5 w-3.5" /> Fontes
          </button>
          <button
            onClick={() => (onEdit ? onEdit() : toast.info("Modo de edição em breve"))}
            className="h-9 px-4 rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            <Pencil className="h-3.5 w-3.5" /> Editar Layout
          </button>
        </div>
      </div>

      {/* Row 2 — período chips */}
      <div className="h-14 flex items-center gap-3 px-5 border-t border-border bg-muted/20">
        <span className="text-xs font-semibold text-muted-foreground mr-1">
          Período
        </span>

        <button
          onClick={() => { /* no-op when already active */ }}
          className={cn(
            "h-8 px-4 rounded-md text-xs font-medium border transition-colors",
            "border-primary bg-primary/5 text-primary"
          )}
        >
          {currentChipLabel}
        </button>

        <button
          onClick={() => onDatePresetChange("last_7d")}
          className={cn(
            "h-8 px-4 rounded-md text-xs border transition-colors",
            presetIsWeek && !presetIsCustom
              ? "border-primary text-primary font-medium"
              : "border-transparent text-muted-foreground hover:bg-muted hover:text-foreground"
          )}
        >
          Semana
        </button>
        <button
          onClick={() => onDatePresetChange("this_month")}
          className={cn(
            "h-8 px-4 rounded-md text-xs border transition-colors",
            presetIsMonth
              ? "border-primary text-primary font-medium"
              : "border-transparent text-muted-foreground hover:bg-muted hover:text-foreground"
          )}
        >
          Mês
        </button>

        <div className="relative">
          <button
            onClick={() => setCustomOpen((o) => !o)}
            className={cn(
              "h-8 px-4 rounded-md text-xs border transition-colors flex items-center gap-1.5",
              datePreset.startsWith("custom:")
                ? "border-primary text-primary font-medium"
                : "border-transparent text-muted-foreground hover:bg-muted hover:text-foreground"
            )}
          >
            <CalendarRange className="h-4 w-4" /> Personalizado
          </button>
          {customOpen && (
            <div className="absolute left-0 top-10 z-30">
              <DateRangePicker
                value={datePreset}
                onChange={(v) => { onDatePresetChange(v); setCustomOpen(false); }}
              />
            </div>
          )}
        </div>

        <div className="ml-auto flex items-center gap-3">
          {rightExtra}
          <div className="h-4 w-px bg-border mx-1" />
          <button
            onClick={() => onToggleCompare?.()}
            className={cn(
              "text-xs transition-colors flex items-center gap-1.5",
              compareEnabled ? "text-primary font-medium" : "text-muted-foreground hover:text-foreground"
            )}
          >
            <div className={cn("h-3 w-3 rounded-full border", compareEnabled ? "bg-primary border-primary" : "border-muted-foreground")} />
            Comparar com período anterior
          </button>
        </div>
      </div>
    </div>
  );
}
