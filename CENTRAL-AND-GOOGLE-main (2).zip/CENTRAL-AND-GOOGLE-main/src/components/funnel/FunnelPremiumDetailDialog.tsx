import { useMemo, useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { PanelCard } from "@/components/dashboard/overview/premium/PanelCard";
import { Campaign } from "@/data/mockMetaData";
import { BestAdsList } from "@/components/dashboard/overview/BestAdsList";
import { FunnelPreviewCard, MetricSpec } from "@/components/funnel/FunnelPreviewCard";
import { useFunnelLabels } from "@/hooks/useFunnelLabels";
import { motion } from "framer-motion";
import {
  Activity,
  Target,
  ArrowDownRight,
  Eye,
  Users,
  MousePointerClick,
  HeartHandshake,
  Settings,
  ArrowUp,
  ArrowDown,
  Plus,
  Trash2,
  RotateCcw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  useSaveFunnelPeriodMetric,
  useDeleteFunnelPeriodMetric,
  presetToRange,
} from "@/hooks/useFunnelPeriodMetrics";

interface Props {
  open: boolean;
  onClose: () => void;
  clientId: string;
  funnelCode: string;
  funnelLabel: string;
  campaigns: Campaign[];
  currencySymbol?: string;
  datePreset: string;
  readOnly?: boolean;
  isManual?: boolean;
}

interface AdSetRow {
  name: string;
  campaignName: string;
  spend: number;
  impressions: number;
  clicks: number;
  conversions: number;
  ctr: number;
  cpa: number;
  adsCount: number;
}

function aggregateAdSets(campaigns: Campaign[]): AdSetRow[] {
  const map = new Map<string, AdSetRow>();
  for (const c of campaigns) {
    for (const cr of c.creatives || []) {
      const name = cr.adsetName || "Sem conjunto";
      const key = `${c.id}|${name}`;
      const result = cr.primaryResult ?? cr.conversions ?? 0;
      const cur = map.get(key) || {
        name,
        campaignName: c.name,
        spend: 0,
        impressions: 0,
        clicks: 0,
        conversions: 0,
        ctr: 0,
        cpa: 0,
        adsCount: 0,
      };
      cur.spend += cr.spend;
      cur.impressions += cr.impressions;
      cur.clicks += cr.clicks;
      cur.conversions += result;
      cur.adsCount += 1;
      map.set(key, cur);
    }
  }
  return Array.from(map.values())
    .map((s) => ({
      ...s,
      ctr: s.impressions > 0 ? Number(((s.clicks / s.impressions) * 100).toFixed(2)) : 0,
      cpa: s.conversions > 0 ? Number((s.spend / s.conversions).toFixed(2)) : 0,
    }))
    .sort((a, b) => b.conversions - a.conversions);
}

function calculateHealth(campaigns: Campaign[]) {
  const t = campaigns.reduce((acc, c) => {
    acc.impressions += c.impressions || 0;
    acc.clicks += c.clicks || 0;
    acc.videoView3s += c.videoView3s || 0;
    acc.thruplays += c.thruplays || 0;
    acc.linkClicks += c.linkClicks || 0;
    acc.landingPageViews += c.landingPageViews || 0;
    acc.addToCart += c.addToCart || 0;
    acc.initiateCheckout += c.initiateCheckout || 0;
    acc.purchases += c.purchases || 0;
    acc.leads += c.conversions || 0;
    return acc;
  }, { impressions: 0, clicks: 0, videoView3s: 0, thruplays: 0, linkClicks: 0, landingPageViews: 0, addToCart: 0, initiateCheckout: 0, purchases: 0, leads: 0 });

  return {
    ctr: t.impressions > 0 ? (t.clicks / t.impressions) * 100 : 0,
    hookRate: t.impressions > 0 ? (t.videoView3s / t.impressions) * 100 : 0,
    holdRate: t.impressions > 0 ? (t.thruplays / t.impressions) * 100 : 0,
    pageViewRate: t.linkClicks > 0 ? (t.landingPageViews / t.linkClicks) * 100 : 0,
    checkoutRate: t.addToCart > 0 ? (t.initiateCheckout / t.addToCart) * 100 : 0,
    conversionToPurchase: t.initiateCheckout > 0 ? (t.purchases / t.initiateCheckout) * 100 : 0,
    conversionToLead: t.landingPageViews > 0 ? (t.leads / t.landingPageViews) * 100 : 0,
  };
}

export function FunnelPremiumDetailDialog({
  open,
  onClose,
  clientId,
  funnelCode,
  funnelLabel,
  campaigns,
  currencySymbol = "R$",
  datePreset,
  readOnly = false,
  isManual = false,
}: Props) {
  const { data: labelMap } = useFunnelLabels(clientId);
  const displayLabel = (labelMap?.[funnelCode] || funnelLabel || funnelCode).replace(/^F\d+\s*[\-—]\s*/, "");

  const allAdSets = useMemo(() => aggregateAdSets(campaigns), [campaigns]);
  const topAdSets = useMemo(() => allAdSets.slice(0, 3), [allAdSets]);
  const [showAllAdSets, setShowAllAdSets] = useState(false);

  const health = useMemo(() => calculateHealth(campaigns), [campaigns]);

  const [funnelSteps, setFunnelSteps] = useState<MetricSpec[]>([]);

  const saveMetric = useSaveFunnelPeriodMetric();
  const deleteMetric = useDeleteFunnelPeriodMetric();

  const journeyStorageKey = `funnel-journey-kpis:${clientId}:${funnelCode}`;
  const [journeyKeys, setJourneyKeys] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(journeyStorageKey);
      if (saved) return JSON.parse(saved);
    } catch {}
    return ["impressions", "clicks", "landingPageViews", "leads", "sales"];
  });

  useEffect(() => {
    localStorage.setItem(journeyStorageKey, JSON.stringify(journeyKeys));
  }, [journeyKeys, journeyStorageKey]);

  const DEFAULT_LABELS: Record<string, string> = {
    impressions: "Impressões",
    reach: "Alcance",
    clicks: "Cliques",
    linkClicks: "Cliques no link",
    landingPageViews: "V. Página Destino",
    profileVisits: "Visitas ao Perfil",
    follows: "Seguidores",
    addToCart: "Adições ao Carrinho",
    initiateCheckout: "Início Checkout (IC)",
    leads: "Leads",
    completeRegistration: "Cadastros",
    conversions: "Conversões",
    sales: "Vendas",
  };

  const activeSteps = useMemo(() => {
    return journeyKeys.map(key => {
      const spec = funnelSteps.find(s => s.key === key);
      return {
        key,
        label: spec?.label || DEFAULT_LABELS[key] || key.replace(/([A-Z])/g, ' $1').replace(/_/g, " "),
        value: spec?.value || 0,
        isManualOverride: spec?.isManualOverride || false,
        format: spec?.format || "number",
      };
    });
  }, [journeyKeys, funnelSteps]);

  // Filter only positive/formatted volume values to draw the funnel shape beautifully
  const chartSteps = useMemo(() => {
    return activeSteps.filter(s => s.value > 0);
  }, [activeSteps]);

  const moveStep = (index: number, direction: -1 | 1) => {
    const nextKeys = [...journeyKeys];
    const targetIndex = index + direction;
    if (targetIndex < 0 || targetIndex >= nextKeys.length) return;
    const temp = nextKeys[index];
    nextKeys[index] = nextKeys[targetIndex];
    nextKeys[targetIndex] = temp;
    setJourneyKeys(nextKeys);
  };

  const allCreatives = useMemo(() => campaigns, [campaigns]);

  const HEALTH_OPTIONS = useMemo(() => [
    { key: "ctr", label: "CTR", ideal: 1.5, suffix: "%" },
    { key: "hookRate", label: "Hook Rate", ideal: 25, suffix: "%", sub: "Visualizações 3s" },
    { key: "holdRate", label: "Hold Rate", ideal: 10, suffix: "%", sub: "Retenção no Vídeo" },
    { key: "pageViewRate", label: "LP View Rate", ideal: 75, suffix: "%", sub: "Carregamento da página" },
    { key: "conversionToLead", label: "Conv. Leads", ideal: 20, suffix: "%", sub: "LP para Lead" },
    { key: "checkoutRate", label: "Checkout Rate", ideal: 15, suffix: "%", sub: "Carrinho para Checkout" },
    { key: "conversionToPurchase", label: "Conv. Vendas", ideal: 20, suffix: "%", sub: "Checkout para Venda" }
  ], []);

  const healthStorageKey = `funnel-health-kpis:${clientId}:${funnelCode}`;
  const [selectedHealth, setSelectedHealth] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(healthStorageKey);
      if (saved) return JSON.parse(saved);
    } catch {}
    return HEALTH_OPTIONS.map(o => o.key);
  });

  useEffect(() => {
    localStorage.setItem(healthStorageKey, JSON.stringify(selectedHealth));
  }, [selectedHealth, healthStorageKey]);

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent
        className="!max-w-none !w-[96vw] !h-[96vh] md:!w-[90vw] md:!h-[90vh] !rounded-2xl p-0 gap-0 border border-border/40 shadow-2xl bg-background overflow-hidden flex flex-col"
      >
        <DialogHeader className="px-6 py-5 border-b border-border/40 bg-muted/20 shrink-0">
          <DialogTitle className="flex items-center justify-between w-full pr-6 text-xl">
            <div className="flex items-center gap-3">
              <span className="text-xs font-mono uppercase tracking-[0.1em] px-2 py-1 rounded-md border border-primary/30 text-primary bg-primary/5">
                {funnelCode}
              </span>
              <span className="font-semibold tracking-tight text-foreground">
                {displayLabel}
              </span>
              {isManual && (
                <span className="ml-2 text-xs font-mono uppercase tracking-[0.1em] px-2 py-1 rounded bg-muted text-muted-foreground border border-border/50">
                  Manual
                </span>
              )}
            </div>
          </DialogTitle>
        </DialogHeader>

        <ScrollArea className="flex-1 w-full relative">
          <div className="p-6 md:p-8 space-y-8 pb-10">
            {/* 1. KPIs */}
            <div className="relative z-10 w-full mb-2">
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2"><Target className="h-4 w-4 text-primary" /> Visão Geral do Funil</h3>
              <FunnelPreviewCard
                clientId={clientId}
                funnelCode={funnelCode}
                funnelLabel={displayLabel}
                campaigns={campaigns}
                currencySymbol={currencySymbol}
                readOnly={readOnly}
                datePreset={datePreset}
                isManual={isManual}
                onOpenDetail={() => {}}
                hideOpenDetail
                exposeMetrics={setFunnelSteps}
              />
            </div>

            {!isManual && (
              <>
                {/* 2. Saúde do Funil */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-semibold flex items-center gap-2"><Activity className="h-4 w-4 text-primary" /> Saúde e Desempenho</h3>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-7 w-7"><Settings className="h-4 w-4" /></Button>
                      </PopoverTrigger>
                      <PopoverContent align="end" className="w-[260px] p-0">
                        <div className="p-3 border-b border-border bg-muted/20">
                          <h4 className="text-sm font-semibold">Métricas de Saúde</h4>
                          <p className="text-[11px] text-muted-foreground">Escolha o que deseja visualizar</p>
                        </div>
                        <div className="p-3 space-y-2">
                          {HEALTH_OPTIONS.map(opt => (
                            <label key={opt.key} className="flex items-center gap-2 text-sm cursor-pointer hover:bg-muted/30 p-1 rounded-sm">
                              <Checkbox 
                                checked={selectedHealth.includes(opt.key)}
                                onCheckedChange={(c) => {
                                  if (c) setSelectedHealth([...selectedHealth, opt.key]);
                                  else setSelectedHealth(selectedHealth.filter(k => k !== opt.key));
                                }}
                              />
                              <span className="flex-1 font-medium">{opt.label}</span>
                            </label>
                          ))}
                        </div>
                      </PopoverContent>
                    </Popover>
                  </div>
                  {selectedHealth.length > 0 ? (
                    <div className={`grid grid-cols-2 md:grid-cols-4 ${selectedHealth.length >= 7 ? 'lg:grid-cols-7' : selectedHealth.length === 6 ? 'lg:grid-cols-6' : selectedHealth.length === 5 ? 'lg:grid-cols-5' : 'lg:grid-cols-4'} gap-3`}>
                      {HEALTH_OPTIONS.filter(o => selectedHealth.includes(o.key)).map(opt => (
                        <HealthCard 
                          key={opt.key} 
                          label={opt.label} 
                          value={(health as any)[opt.key] || 0} 
                          ideal={opt.ideal} 
                          suffix={opt.suffix} 
                          sub={opt.sub} 
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="text-xs text-muted-foreground italic py-2">Nenhuma métrica de saúde selecionada.</div>
                  )}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-7 gap-6">
                  {/* 3. Funnel Flow Visualizer */}
                  <div className="lg:col-span-3 flex flex-col h-full">
                    <PanelCard 
                      title="Jornada do Usuário" 
                      subtitle="Volume absoluto por etapa configurada"
                      actions={
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-7 w-7" title="Configurar Funil / Etapas"><Settings className="h-4 w-4" /></Button>
                          </PopoverTrigger>
                          <PopoverContent align="end" className="w-[340px] p-4 shadow-xl border border-border bg-card max-h-[80vh] flex flex-col gap-3 overflow-hidden">
                            <div className="border-b border-border pb-2 shrink-0">
                              <h4 className="text-sm font-semibold">Configurar Jornada</h4>
                              <p className="text-[11px] text-muted-foreground mt-0.5">Defina as etapas, ordem e valores manuais</p>
                            </div>
                            
                            <ScrollArea className="flex-1 -mx-2 px-2 max-h-[50vh]">
                              <div className="space-y-4 py-1">
                                {journeyKeys.map((key, idx) => {
                                  const spec = activeSteps.find(s => s.key === key) || {
                                    key,
                                    label: DEFAULT_LABELS[key] || key,
                                    value: 0,
                                    isManualOverride: false,
                                    format: "number" as const,
                                  };
                                  return (
                                    <div key={key} className="p-2.5 rounded-lg border border-border/60 bg-muted/20 flex flex-col gap-1.5 shadow-sm">
                                      <div className="flex items-center justify-between gap-2">
                                        <span className="text-xs font-semibold truncate flex-1">{spec.label}</span>
                                        <div className="flex items-center gap-0.5">
                                          <Button
                                            size="icon"
                                            variant="ghost"
                                            className="h-5 w-5 rounded hover:bg-muted"
                                            disabled={idx === 0}
                                            onClick={() => moveStep(idx, -1)}
                                          >
                                            <ArrowUp className="h-3 w-3" />
                                          </Button>
                                          <Button
                                            size="icon"
                                            variant="ghost"
                                            className="h-5 w-5 rounded hover:bg-muted"
                                            disabled={idx === journeyKeys.length - 1}
                                            onClick={() => moveStep(idx, 1)}
                                          >
                                            <ArrowDown className="h-3 w-3" />
                                          </Button>
                                          <Button
                                            size="icon"
                                            variant="ghost"
                                            className="h-5 w-5 rounded hover:bg-muted text-muted-foreground hover:text-destructive"
                                            onClick={() => setJourneyKeys(journeyKeys.filter(k => k !== key))}
                                          >
                                            <Trash2 className="h-3 w-3" />
                                          </Button>
                                        </div>
                                      </div>

                                      <div className="flex items-center gap-1.5 bg-background border border-border/80 rounded px-2 py-1">
                                        <span className="text-[10px] text-muted-foreground flex-1 truncate">
                                          {spec.isManualOverride ? "Valor Manual" : "Valor Auto: " + spec.value}
                                        </span>
                                        <Input
                                          type="number"
                                          placeholder={String(spec.value)}
                                          defaultValue={spec.isManualOverride ? String(spec.value) : ""}
                                          className="h-6 w-20 text-xs px-1 text-right focus-visible:ring-1 bg-transparent border-0 ring-0 focus-visible:ring-0 p-0"
                                          onKeyDown={async (e) => {
                                            if (e.key === "Enter") {
                                              const val = e.currentTarget.value;
                                              const range = datePreset ? presetToRange(datePreset) : null;
                                              if (!range) return;
                                              if (val === "" || val === undefined) {
                                                await deleteMetric.mutateAsync({
                                                  client_id: clientId,
                                                  funnel_code: funnelCode,
                                                  metric_key: key,
                                                  period_start: range.start,
                                                  period_end: range.end,
                                                });
                                                toast.success("Voltou ao valor automático");
                                              } else {
                                                const numVal = Number(val);
                                                if (Number.isFinite(numVal)) {
                                                  await saveMetric.mutateAsync({
                                                    client_id: clientId,
                                                    funnel_code: funnelCode,
                                                    metric_key: key,
                                                    metric_label: spec.label,
                                                    metric_value: numVal,
                                                    period_start: range.start,
                                                    period_end: range.end,
                                                    source: "manual_edit",
                                                  });
                                                  toast.success("Valor manual salvo");
                                                }
                                              }
                                            }
                                          }}
                                        />
                                        {spec.isManualOverride && (
                                          <Button
                                            size="icon"
                                            variant="ghost"
                                            className="h-5 w-5 text-muted-foreground hover:text-primary rounded"
                                            title="Restaurar automático"
                                            onClick={async () => {
                                              const range = datePreset ? presetToRange(datePreset) : null;
                                              if (!range) return;
                                              await deleteMetric.mutateAsync({
                                                client_id: clientId,
                                                funnel_code: funnelCode,
                                                metric_key: key,
                                                period_start: range.start,
                                                period_end: range.end,
                                              });
                                              toast.success("Voltou ao valor automático");
                                            }}
                                          >
                                            <RotateCcw className="h-3 w-3" />
                                          </Button>
                                        )}
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </ScrollArea>
                            
                            <div className="border-t border-border pt-3 shrink-0">
                              <select
                                className="flex h-8 w-full rounded-md border border-input bg-background px-3 py-1 text-xs shadow-sm focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring cursor-pointer"
                                onChange={(e) => {
                                  const val = e.target.value;
                                  if (val) {
                                    setJourneyKeys([...journeyKeys, val]);
                                    e.target.value = "";
                                  }
                                }}
                                defaultValue=""
                              >
                                <option value="" disabled>+ Adicionar Etapa / Métrica...</option>
                                {(() => {
                                  const defaults = Object.keys(DEFAULT_LABELS);
                                  const fromSteps = funnelSteps.map(s => s.key);
                                  const uniques = Array.from(new Set([...defaults, ...fromSteps]));
                                  const available = uniques.filter(k => !journeyKeys.includes(k));
                                  return available.map(k => {
                                    const spec = funnelSteps.find(s => s.key === k);
                                    const label = spec?.label || DEFAULT_LABELS[k] || k;
                                    return <option key={k} value={k}>{label}</option>;
                                  });
                                })()}
                              </select>
                            </div>
                            <p className="text-[9px] text-muted-foreground text-center mt-1">Insira um valor e pressione Enter para salvar o manual.</p>
                          </PopoverContent>
                        </Popover>
                      }
                    >
                      {chartSteps.length >= 2 ? (
                        <div className="flex flex-col items-center justify-center py-6 h-full min-h-[300px]">
                          {chartSteps.map((step, i) => {
                            const prev = i > 0 ? chartSteps[i - 1].value : null;
                            const conversion = prev && prev > 0 ? (step.value / prev) * 100 : null;
                            const wTop = 100 - (i * 12);
                            const wBottom = 100 - ((i + 1) * 12);
                            const shade = 1 - (i * 0.15);

                            return (
                              <div key={step.key} className="w-full flex flex-col items-center">
                                <motion.div
                                  initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }}
                                  transition={{ delay: i * 0.1 }}
                                  className="relative flex items-center justify-center text-primary-foreground shadow-sm"
                                  style={{
                                    height: '56px',
                                    width: `${wTop}%`,
                                    background: `hsl(var(--primary) / ${shade})`,
                                    clipPath: `polygon(0 0, 100% 0, calc(50% + ${wBottom/2}%) 100%, calc(50% - ${wBottom/2}%) 100%)`,
                                  }}
                                >
                                  <div className="flex gap-2 items-center px-4 font-medium tracking-tight">
                                    <span className="text-xs">{step.label}</span>
                                    <span className="text-sm font-bold tabular-nums">
                                      {step.value >= 1000 ? (step.value/1000).toFixed(1)+'k' : step.value}
                                    </span>
                                  </div>
                                </motion.div>
                                {conversion !== null && i > 0 && (
                                  <div className="py-1 flex flex-col items-center text-[10px] text-muted-foreground/80 font-medium">
                                    <span className="flex items-center gap-1"><ArrowDownRight className="w-3 h-3" /> {conversion.toFixed(1)}%</span>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center h-[300px] text-center p-6 text-muted-foreground">
                          <p className="text-sm">Configuração de funil insuficiente para renderização.</p>
                          <p className="text-xs mt-2 font-mono bg-muted/40 p-2.5 rounded-md border border-border/40 max-w-[90%]">
                            Dica: Clique no ícone de engrenagem <Settings className="inline h-3 w-3" /> acima para adicionar as etapas desejadas no funil.
                          </p>
                        </div>
                      )}
                    </PanelCard>
                  </div>

                  {/* 4. Top Ads & AdSets list */}
                  <div className="lg:col-span-4 flex flex-col gap-6">
                    <PanelCard 
                      title="Top Conjuntos de Anúncio" 
                      action={
                         allAdSets.length > 3 && (
                           <Dialog open={showAllAdSets} onOpenChange={setShowAllAdSets}>
                             <DialogTrigger asChild>
                               <Button variant="ghost" size="sm" className="h-7 text-xs px-2 gap-1"><Eye className="w-3 h-3"/> Ver todos</Button>
                             </DialogTrigger>
                             <DialogContent className="max-w-2xl h-[70vh] flex flex-col">
                               <DialogHeader><DialogTitle>Todos os Conjuntos (Ordem de Conversões)</DialogTitle></DialogHeader>
                               <ScrollArea className="flex-1 -mx-4 px-4">
                                 <div className="space-y-2 py-4">
                                   {allAdSets.map((s, i) => <AdSetCard key={i} s={s} i={i} currencySymbol={currencySymbol} />)}
                                 </div>
                               </ScrollArea>
                             </DialogContent>
                           </Dialog>
                         )
                      }
                    >
                      {topAdSets.length > 0 ? (
                        <div className="grid grid-cols-1 gap-2">
                          {topAdSets.map((s, i) => <AdSetCard key={i} s={s} i={i} currencySymbol={currencySymbol} />)}
                        </div>
                      ) : (
                        <p className="text-xs text-muted-foreground italic py-4">Nenhum conjunto encontrado.</p>
                      )}
                    </PanelCard>

                    <PanelCard title="Top Criativos e Anúncios" subtitle="Ranking de desempenho">
                      <BestAdsList
                        campaigns={allCreatives}
                        limit={3}
                        metrics={["primaryResult", "ctr", "spend"]}
                        currencySymbol={currencySymbol}
                      />
                    </PanelCard>
                  </div>
                </div>
              </>
            )}

            {isManual && (
              <div className="text-center py-20 px-6 border border-border/50 rounded-lg bg-muted/10 border-dashed">
                <Target className="w-8 h-8 text-muted-foreground mx-auto mb-3 opacity-50" />
                <h3 className="text-base font-medium mb-1">Este é um funil de inserção manual</h3>
                <p className="text-sm text-muted-foreground max-w-md mx-auto">
                  Sem sincronização ativa com Meta Ads ou Fontes Externas.
                  Os totais absolutos do funil são definidos diretamente nos cards no topo da página.
                </p>
              </div>
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}

function HealthCard({ label, value, ideal, suffix = "", sub }: { label: string, value: number, ideal: number, suffix?: string, sub?: string }) {
  const isGood = value >= ideal;
  const isBad = value < (ideal * 0.6);
  return (
    <div className={`p-3 rounded-lg border flex flex-col gap-1 transition-colors ${isGood ? 'bg-emerald-500/10 border-emerald-500/20' : isBad ? 'bg-rose-500/10 border-rose-500/20' : 'bg-amber-500/10 border-amber-500/20'}`}>
      <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">{label}</span>
      <div className="flex items-end gap-1.5 mt-0.5">
        <span className={`text-lg font-bold tabular-nums ${isGood ? 'text-emerald-500' : isBad ? 'text-rose-500' : 'text-amber-500'}`}>
          {value.toFixed(1)}{suffix}
        </span>
      </div>
      {sub && <span className="text-[9px] text-muted-foreground leading-tight mt-1 truncate" title={sub}>{sub}</span>}
    </div>
  );
}

function AdSetCard({ s, i, currencySymbol }: { s: AdSetRow, i: number, currencySymbol: string }) {
  return (
    <div className="flex items-center gap-4 rounded-xl border border-border/30 bg-muted/20 hover:bg-muted/40 transition-colors p-3 w-full">
      <div className="flex-shrink-0 w-6 flex justify-center">
        <span className="text-xs font-black text-primary/40 bg-primary/10 rounded-full w-6 h-6 flex items-center justify-center">{i + 1}</span>
      </div>
      <div className="flex-1 min-w-0 pr-4 border-r border-border/40">
        <p className="text-[13px] font-semibold truncate text-foreground/90" title={s.name}>{s.name || "Sem nome"}</p>
        <div className="flex items-center gap-3 mt-1.5 text-[10px] text-muted-foreground font-medium">
          <span className="flex items-center gap-1"><Users className="w-3 h-3 text-muted-foreground/60"/> {s.adsCount} anúncios</span>
          <span className="flex items-center gap-1"><MousePointerClick className="w-3 h-3 text-muted-foreground/60"/> CTR {s.ctr}%</span>
        </div>
      </div>
      <div className="flex-shrink-0 text-right min-w-[90px]">
        <p className="text-sm font-extrabold tabular-nums text-foreground/90 flex items-center justify-end gap-1"><HeartHandshake className="w-3.5 h-3.5 text-primary/70"/> {(s.conversions || 0).toLocaleString("pt-BR")}</p>
        <p className="text-[10px] text-muted-foreground mt-1 tabular-nums font-medium">
          CPA {currencySymbol}{(s.cpa || 0).toFixed(2)}
        </p>
      </div>
    </div>
  );
}