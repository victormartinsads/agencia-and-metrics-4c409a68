import { useEffect, useMemo, useState } from "react";
import { motion, Reorder } from "framer-motion";
import {
  Pencil, Check, X, ArrowRight, DollarSign, TrendingUp, Target, ShoppingCart, Users,
  Settings, MousePointerClick, Eye, BarChart3, Percent, Activity, UserPlus, Plus, Trash2, GripVertical, GripHorizontal
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger, PopoverClose } from "@/components/ui/popover";
import { Checkbox } from "@/components/ui/checkbox";
import { Campaign } from "@/data/mockMetaData";
import { aggregateCampaignMetrics } from "@/lib/metaMetrics";
import { formatCurrency } from "@/lib/format";
import { EditableKpiCell } from "@/components/funnel/EditableKpiCell";
import {
  useFunnelLabels, useSaveFunnelLabel,
} from "@/hooks/useFunnelLabels";
import { useFunnelLeadMapping } from "@/hooks/useFunnelLeadMapping";
import {
  useFunnelPeriodMetrics,
  useSaveFunnelPeriodMetric,
  presetToRange,
} from "@/hooks/useFunnelPeriodMetrics";
import { useUpdateManualFunnel, useDeleteManualFunnel } from "@/hooks/useManualFunnels";
import { toast } from "sonner";

interface Props {
  clientId: string;
  funnelCode: string;
  funnelLabel: string;
  campaigns: Campaign[];
  currencySymbol?: string;
  readOnly?: boolean;
  onOpenDetail: () => void;
  datePreset?: string;
  /** When true, no Meta auto-values are computed; everything comes from manual overrides. */
  isManual?: boolean;
  /** ID of the manual funnel row, used for rename/delete. */
  manualId?: string;
  /** When true, hides the "Análise completa" button (used when embedded inside the dialog). */
  hideOpenDetail?: boolean;
  /** Callback to expose final metrics to parent */
  exposeMetrics?: (metrics: MetricSpec[]) => void;
}

function compact(n: number) {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  if (n >= 1_000) return (n / 1_000).toFixed(1).replace(/\.0$/, "") + "k";
  return n.toLocaleString("pt-BR");
}

const DEFAULT_KPIS = ["spend", "revenue", "roas", "sales", "leads"];

export type Format = "currency" | "number" | "percent" | "multiplier";
export interface MetricSpec {
  key: string;
  label: string;
  format: Format;
  icon: JSX.Element;
  sub?: string;
  emphasis?: boolean;
  /** Whether the value comes from a manual override. */
  isManualOverride: boolean;
  /** Raw numeric value. */
  value: number;
  /** Whether this is a fully user-added (custom) metric. */
  isCustom?: boolean;
}

function formatValue(v: number, fmt: Format, currencySymbol: string, blankWhenZero = false) {
  if (blankWhenZero && (!v || v === 0)) return "—";
  switch (fmt) {
    case "currency": return formatCurrency(v, currencySymbol);
    case "percent":  return `${v.toFixed(2)}%`;
    case "multiplier": return `${v.toFixed(2)}x`;
    default: return compact(v);
  }
}

export function FunnelPreviewCard({
  clientId,
  funnelCode,
  funnelLabel,
  campaigns,
  currencySymbol = "R$",
  readOnly = false,
  onOpenDetail,
  datePreset,
  isManual = false,
  manualId,
  hideOpenDetail = false,
  exposeMetrics,
}: Props) {
  const { data: labelMap } = useFunnelLabels(clientId);
  const saveLabel = useSaveFunnelLabel();
  const { data: leadMap } = useFunnelLeadMapping(clientId);
  const { data: periodMetrics } = useFunnelPeriodMetrics(clientId, funnelCode, datePreset);
  const saveMetric = useSaveFunnelPeriodMetric();
  const updateManual = useUpdateManualFunnel();
  const deleteManual = useDeleteManualFunnel();

  const leadActionTypes = leadMap?.[funnelCode] || [];
  const totals = isManual
    ? { 
        spend: 0, purchaseValue: 0, purchases: 0, leads: 0, conversions: 0, impressions: 0, clicks: 0, 
        landingPageViews: 0, linkClicks: 0, addToCart: 0, initiateCheckout: 0, hookRate: 0, holdRate: 0, 
        videoView3s: 0, thruplays: 0, follows: 0, profit: 0, reach: 0, frequency: 0, cpcLink: 0, 
        checkoutRate: 0, cpAddToCart: 0, cpInitiateCheckout: 0, messages: 0, cpMessage: 0, profileVisits: 0
      } as any
    : aggregateCampaignMetrics(campaigns, { leadActionTypes });

  const baseLabel = (labelMap?.[funnelCode] || funnelLabel || funnelCode).replace(/^F\d+\s*[\-—]\s*/, "");

  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(baseLabel);
  useEffect(() => setDraft(baseLabel), [baseLabel]);

  // ---------- helpers to read overrides ----------
  const overrideMap = useMemo(() => {
    const m: Record<string, { value: number; label: string }> = {};
    for (const r of periodMetrics || []) {
      m[r.metric_key] = { value: Number(r.metric_value) || 0, label: r.metric_label || r.metric_key };
    }
    return m;
  }, [periodMetrics]);

  const getOverride = (key: string) => overrideMap[key];
  const resolve = (key: string, auto: number) => {
    const o = getOverride(key);
    return o 
      ? { value: o.metric_value !== undefined ? Number(o.metric_value) : Number(o.value || 0), isManualOverride: true, label: o.metric_label || o.label } 
      : { value: auto, isManualOverride: false, label: undefined };
  };

  // ---------- base metric values ----------
  const spendR = resolve("spend", totals.spend || 0);
  const revenueR = resolve("revenue", totals.purchaseValue || 0);
  const salesR = resolve("sales", totals.purchases || 0);
  const leadsR = resolve("leads", totals.leads || totals.conversions || 0);
  const impressionsR = resolve("impressions", (totals as any).impressions || 0);
  const clicksR = resolve("clicks", (totals as any).clicks || 0);
  const followersR = resolve("followers", (totals as any).follows || 0);
  
  const landingPageViewsR = resolve("landingPageViews", (totals as any).landingPageViews || 0);
  const linkClicksR = resolve("linkClicks", (totals as any).linkClicks || 0);
  const addToCartR = resolve("addToCart", totals.addToCart || 0);
  const initiateCheckoutR = resolve("initiateCheckout", totals.initiateCheckout || 0);
  
  const videoView3sR = resolve("videoView3s", totals.videoView3s || 0);
  const thruplaysR = resolve("thruplays", totals.thruplays || 0);
  const hookRateR = resolve("hookRate", totals.hookRate || 0);
  const holdRateR = resolve("holdRate", totals.holdRate || 0);

  const profitR = resolve("profit", totals.profit || 0);
  const reachR = resolve("reach", totals.reach || 0);
  const frequencyR = resolve("frequency", totals.frequency || 0);
  const cpcLinkR = resolve("cpcLink", totals.cpcLink || 0);
  const checkoutRateR = resolve("checkoutRate", totals.checkoutRate || 0);
  const cpAddToCartR = resolve("cpAddToCart", totals.cpAddToCart || 0);
  const cpInitiateCheckoutR = resolve("cpInitiateCheckout", totals.cpInitiateCheckout || 0);
  const messagesR = resolve("messages", totals.messages || 0);
  const cpMessageR = resolve("cpMessage", totals.cpMessage || 0);
  const profileVisitsR = resolve("profileVisits", totals.profileVisits || 0);

  // derived (allow override too)
  const spend = spendR.value, revenue = revenueR.value, sales = salesR.value, leads = leadsR.value;
  const impressions = impressionsR.value, clicks = clicksR.value, followers = followersR.value;

  const autoRoas = spend > 0 ? revenue / spend : 0;
  const autoCtr  = impressions > 0 ? (clicks / impressions) * 100 : 0;
  const autoCpc  = clicks > 0 ? spend / clicks : 0;
  const autoCpm  = impressions > 0 ? (spend / impressions) * 1000 : 0;
  const autoCpl  = leads > 0 ? spend / leads : 0;
  const autoCpa  = sales > 0 ? spend / sales : 0;
  const autoCps  = followers > 0 ? spend / followers : 0;

  const roasR = resolve("roas", autoRoas);
  const ctrR  = resolve("ctr",  autoCtr);
  const cpcR  = resolve("cpc",  autoCpc);
  const cpmR  = resolve("cpm",  autoCpm);
  const cplR  = resolve("cpl",  autoCpl);
  const cpaR  = resolve("cpa",  autoCpa);
  const cpsR  = resolve("cps",  autoCps);

  const isCaptacao = funnelCode === "F1";

  const KPI_CATALOG: Record<string, MetricSpec> = {
    spend:       { key: "spend", label: spendR.label || "Investimento", format: "currency", value: spend, isManualOverride: spendR.isManualOverride, sub: "vs. período anterior", icon: <DollarSign className="h-3 w-3" /> },
    revenue:     { key: "revenue", label: revenueR.label || "Faturamento", format: "currency", value: revenue, isManualOverride: revenueR.isManualOverride, emphasis: true, sub: "vs. período anterior", icon: <TrendingUp className="h-3 w-3" /> },
    profit:      { key: "profit", label: profitR.label || "Lucro", format: "currency", value: profitR.value, isManualOverride: profitR.isManualOverride, icon: <TrendingUp className="h-3 w-3" /> },
    roas:        { key: "roas", label: roasR.label || "ROAS", format: "multiplier", value: roasR.value, isManualOverride: roasR.isManualOverride, sub: "Meta: 3.5x", icon: <Target className="h-3 w-3" /> },
    sales:       { key: "sales", label: salesR.label || "Vendas", format: "number", value: sales, isManualOverride: salesR.isManualOverride, sub: cpaR.value > 0 ? `CPV ${formatCurrency(cpaR.value, currencySymbol)}` : "—", icon: <ShoppingCart className="h-3 w-3" /> },
    leads:       { key: "leads", label: leadsR.label || "Leads", format: "number", value: leads, isManualOverride: leadsR.isManualOverride, sub: cplR.value > 0 ? `CPL ${formatCurrency(cplR.value, currencySymbol)}` : undefined, icon: <Users className="h-3 w-3" /> },
    messages:    { key: "messages", label: messagesR.label || "Mensagens (Inbox)", format: "number", value: messagesR.value, isManualOverride: messagesR.isManualOverride, icon: <Users className="h-3 w-3" /> },
    reach:       { key: "reach", label: reachR.label || "Alcance", format: "number", value: reachR.value, isManualOverride: reachR.isManualOverride, icon: <Eye className="h-3 w-3" /> },
    impressions: { key: "impressions", label: impressionsR.label || "Impressões", format: "number", value: impressions, isManualOverride: impressionsR.isManualOverride, icon: <Eye className="h-3 w-3" /> },
    frequency:   { key: "frequency", label: frequencyR.label || "Frequência", format: "number", value: frequencyR.value, isManualOverride: frequencyR.isManualOverride, icon: <Activity className="h-3 w-3" /> },
    clicks:      { key: "clicks", label: clicksR.label || "Cliques (Todos)", format: "number", value: clicks, isManualOverride: clicksR.isManualOverride, icon: <MousePointerClick className="h-3 w-3" /> },
    linkClicks:  { key: "linkClicks", label: linkClicksR.label || "Cliques no Link", format: "number", value: linkClicksR.value, isManualOverride: linkClicksR.isManualOverride, icon: <MousePointerClick className="h-3 w-3" /> },
    landingPageViews: { key: "landingPageViews", label: landingPageViewsR.label || "V. Página Destino", format: "number", value: landingPageViewsR.value, isManualOverride: landingPageViewsR.isManualOverride, icon: <Eye className="h-3 w-3" /> },
    addToCart:   { key: "addToCart", label: addToCartR.label || "Add to Cart (ATC)", format: "number", value: addToCartR.value, isManualOverride: addToCartR.isManualOverride, icon: <ShoppingCart className="h-3 w-3" /> },
    initiateCheckout: { key: "initiateCheckout", label: initiateCheckoutR.label || "Início Checkout (IC)", format: "number", value: initiateCheckoutR.value, isManualOverride: initiateCheckoutR.isManualOverride, icon: <ShoppingCart className="h-3 w-3" /> },
    checkoutRate: { key: "checkoutRate", label: checkoutRateR.label || "Tx. Conv. Checkout", format: "percent", value: checkoutRateR.value, isManualOverride: checkoutRateR.isManualOverride, icon: <Percent className="h-3 w-3" /> },
    ctr:         { key: "ctr", label: ctrR.label || "CTR (Todos)", format: "percent", value: ctrR.value, isManualOverride: ctrR.isManualOverride, icon: <Percent className="h-3 w-3" /> },
    cpc:         { key: "cpc", label: cpcR.label || "CPC", format: "currency", value: cpcR.value, isManualOverride: cpcR.isManualOverride, icon: <BarChart3 className="h-3 w-3" /> },
    cpcLink:     { key: "cpcLink", label: cpcLinkR.label || "CPC (Link)", format: "currency", value: cpcLinkR.value, isManualOverride: cpcLinkR.isManualOverride, icon: <BarChart3 className="h-3 w-3" /> },
    cpm:         { key: "cpm", label: cpmR.label || "CPM", format: "currency", value: cpmR.value, isManualOverride: cpmR.isManualOverride, icon: <Activity className="h-3 w-3" /> },
    cpa:         { key: "cpa", label: cpaR.label || "CPA", format: "currency", value: cpaR.value, isManualOverride: cpaR.isManualOverride, icon: <Target className="h-3 w-3" /> },
    cpl:         { key: "cpl", label: cplR.label || "CPL", format: "currency", value: cplR.value, isManualOverride: cplR.isManualOverride, icon: <Users className="h-3 w-3" /> },
    cpMessage:   { key: "cpMessage", label: cpMessageR.label || "Custo por Mensagem", format: "currency", value: cpMessageR.value, isManualOverride: cpMessageR.isManualOverride, icon: <Activity className="h-3 w-3" /> },
    cpAddToCart: { key: "cpAddToCart", label: cpAddToCartR.label || "Custo ATC", format: "currency", value: cpAddToCartR.value, isManualOverride: cpAddToCartR.isManualOverride, icon: <Activity className="h-3 w-3" /> },
    cpInitiateCheckout: { key: "cpInitiateCheckout", label: cpInitiateCheckoutR.label || "Custo IC", format: "currency", value: cpInitiateCheckoutR.value, isManualOverride: cpInitiateCheckoutR.isManualOverride, icon: <Activity className="h-3 w-3" /> },
    followers:   { key: "followers", label: followersR.label || "Seguidores", format: "number", value: followers, isManualOverride: followersR.isManualOverride, sub: followers > 0 ? "input manual" : "sem input", icon: <UserPlus className="h-3 w-3" /> },
    cps:         { key: "cps", label: cpsR.label || "Custo / Seguidor", format: "currency", value: cpsR.value, isManualOverride: cpsR.isManualOverride, emphasis: true, sub: followers > 0 ? `${compact(followers)} seguidores` : "defina seguidores", icon: <UserPlus className="h-3 w-3" /> },
    profileVisits: { key: "profileVisits", label: profileVisitsR.label || "Visitas ao Perfil", format: "number", value: profileVisitsR.value, isManualOverride: profileVisitsR.isManualOverride, icon: <Eye className="h-3 w-3" /> },
    videoView3s: { key: "videoView3s", label: videoView3sR.label || "Video Views (3s)", format: "number", value: videoView3sR.value, isManualOverride: videoView3sR.isManualOverride, icon: <Eye className="h-3 w-3" /> },
    thruplays:   { key: "thruplays", label: thruplaysR.label || "Thruplays", format: "number", value: thruplaysR.value, isManualOverride: thruplaysR.isManualOverride, icon: <Activity className="h-3 w-3" /> },
    hookRate:    { key: "hookRate", label: hookRateR.label || "Hook Rate", format: "percent", value: hookRateR.value, isManualOverride: hookRateR.isManualOverride, icon: <Percent className="h-3 w-3" /> },
    holdRate:    { key: "holdRate", label: holdRateR.label || "Hold Rate", format: "percent", value: holdRateR.value, isManualOverride: holdRateR.isManualOverride, icon: <Percent className="h-3 w-3" /> },
  };

  // Custom user-added metrics (any periodMetric with key starting custom:)
  const customMetrics: MetricSpec[] = useMemo(() => {
    return (periodMetrics || [])
      .filter((m) => m.metric_key.startsWith("custom:"))
      .map((m) => ({
        key: m.metric_key,
        label: m.metric_label || m.metric_key.replace("custom:", ""),
        format: "number" as Format,
        value: Number(m.metric_value) || 0,
        isManualOverride: true,
        isCustom: true,
        icon: <Activity className="h-3 w-3" />,
      }));
  }, [periodMetrics]);

  // Meta Custom Conversions / any action Breakdown
  const metaCustomConversions: MetricSpec[] = useMemo(() => {
    if (isManual) return [];
    const customTypes: Record<string, number> = {};
    const IGNORE_KEYS = [
      "link_click", "post_engagement", "page_engagement", "video_view", "post_reaction", 
      "post_comment", "post", "like", "omni_purchase", "commerce_purcahse", "purchase",
      "lead", "landing_page_view"
    ];

    campaigns.forEach((c) => {
      const ab = (c as any).actionBreakdown;
      if (ab) {
        for (const [k, v] of Object.entries(ab)) {
          if (!IGNORE_KEYS.includes(k) && !KPI_CATALOG[k]) {
            customTypes[k] = (customTypes[k] || 0) + Number(v || 0);
          }
        }
      }
      const actions = (c as any).actions;
      if (Array.isArray(actions)) {
        for (const action of actions) {
          const type = action.action_type || "";
          if (type && !IGNORE_KEYS.includes(type) && !KPI_CATALOG[type]) {
            customTypes[type] = (customTypes[type] || 0) + Number(action.value || 0);
          }
        }
      } else if (actions && typeof actions === "object") {
         for (const [k, v] of Object.entries(actions)) {
          if (!IGNORE_KEYS.includes(k) && !KPI_CATALOG[k]) {
            customTypes[k] = (customTypes[k] || 0) + Number(v || 0);
          }
        }
      }
    });

    return Object.entries(customTypes).map(([k, autoValue]) => {
      const override = overrideMap[k];
      const val = override ? (override.metric_value !== undefined ? Number(override.metric_value) : Number(override.value || 0)) : autoValue;
      const isManualOv = !!override;
      const originalName = k.replace(/^(offsite_conversion\.|onsite_conversion\.|app_custom_event\.)/, "").replace(/_/g, " ");
      
      return {
        key: k,
        label: override?.metric_label || override?.label || originalName,
        format: "number" as Format,
        value: val,
        isManualOverride: isManualOv,
        isCustom: true,
        icon: <Activity className="h-3 w-3" />,
      };
    });
  }, [campaigns, isManual, overrideMap, KPI_CATALOG]);

  const fullCatalog: Record<string, MetricSpec> = { ...KPI_CATALOG };
  for (const c of metaCustomConversions) fullCatalog[c.key] = c;
  for (const c of customMetrics) fullCatalog[c.key] = c;

  // ---------- visible selection ----------
  const storageKey = `funnel-preview-kpis:${clientId}:${funnelCode}`;
  const [selected, setSelected] = useState<string[]>(() => {
    try {
      const raw = localStorage.getItem(storageKey);
      if (raw) return JSON.parse(raw);
    } catch {}
    if (isManual) return ["spend", "leads", "sales", "revenue", "roas"];
    return isCaptacao ? ["spend", "followers", "cps", "leads", "roas"] : DEFAULT_KPIS;
  });
  useEffect(() => {
    try { localStorage.setItem(storageKey, JSON.stringify(selected)); } catch {}
  }, [storageKey, selected]);

  // Auto-include any custom metric not yet in selection
  useEffect(() => {
    if (!customMetrics.length) return;
    setSelected((prev) => {
      const next = [...prev];
      for (const c of customMetrics) if (!next.includes(c.key)) next.push(c.key);
      return next;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customMetrics.length]);

  const visibleKeys = useMemo(() => {
    const base = selected.filter((k) => fullCatalog[k]);
    if (isCaptacao && !isManual) {
      if (!base.includes("cps")) base.unshift("cps");
      if (!base.includes("followers")) base.unshift("followers");
    }
    return base.slice(0, 6);
  }, [selected, fullCatalog, isCaptacao, isManual]);

  useEffect(() => {
    if (exposeMetrics) {
      exposeMetrics(Object.values(fullCatalog));
    }
  }, [fullCatalog, exposeMetrics]);

  const toggleKpi = (key: string) => {
    setSelected((prev) => {
      if (prev.includes(key)) {
        if (prev.length <= 1) return prev;
        return prev.filter((k) => k !== key);
      }
      if (prev.length >= 6) { toast.info("Máximo de 6 métricas"); return prev; }
      return [...prev, key];
    });
  };

  // ---------- label save ----------
  const onSaveLabel = async () => {
    const v = draft.trim();
    if (!v) return;
    try {
      if (isManual && manualId) {
        await updateManual.mutateAsync({ id: manualId, client_id: clientId, label: v });
      } else {
        await saveLabel.mutateAsync({ clientId, funnelCode, label: v });
      }
      toast.success("Nome do funil salvo");
      setEditing(false);
    } catch { toast.error("Erro ao salvar nome"); }
  };

  // ---------- add custom metric ----------
  const [newName, setNewName] = useState("");
  const [newValue, setNewValue] = useState("");
  const handleAddCustom = async () => {
    const name = newName.trim();
    if (!name) { toast.error("Informe um nome"); return; }
    const v = Number(String(newValue).replace(",", "."));
    if (!Number.isFinite(v)) { toast.error("Valor inválido"); return; }
    if (!datePreset) return;
    const range = presetToRange(datePreset);
    const key = `custom:${name.toLowerCase().replace(/\s+/g, "_").replace(/[^a-z0-9_]/g, "")}`;
    try {
      await saveMetric.mutateAsync({
        client_id: clientId,
        funnel_code: funnelCode,
        metric_key: key,
        metric_label: name,
        metric_value: v,
        period_start: range.start,
        period_end: range.end,
        source: "manual_custom",
      });
      toast.success("Métrica adicionada");
      setNewName(""); setNewValue("");
      setSelected((prev) => prev.includes(key) ? prev : [...prev, key]);
    } catch { toast.error("Erro ao adicionar métrica"); }
  };

  // ---------- delete manual funnel ----------
  const handleDeleteManual = async () => {
    if (!manualId) return;
    if (!confirm("Remover este funil manual? Os valores salvos serão mantidos no histórico.")) return;
    try {
      await deleteManual.mutateAsync({ id: manualId, client_id: clientId });
      toast.success("Funil removido");
    } catch { toast.error("Erro ao remover"); }
  };

  const visible = visibleKeys;
  const gridCols = visible.length >= 5 ? "lg:grid-cols-5" : visible.length === 4 ? "lg:grid-cols-4" : visible.length === 3 ? "lg:grid-cols-3" : visible.length === 2 ? "lg:grid-cols-2" : "lg:grid-cols-6";

  return (
    <motion.section
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl bg-card border border-border/60 overflow-hidden"
    >
      <header className="flex items-center justify-between gap-3 px-5 py-3.5 border-b border-border/60">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <span className="h-1.5 w-1.5 rounded-full bg-primary shadow-[0_0_8px_hsl(var(--primary))]" />
          <span className="text-[10px] font-mono uppercase tracking-[0.1em] px-1.5 py-0.5 rounded border border-primary/40 text-primary">
            {funnelCode}
          </span>
          {isManual && (
            <span className="text-[9px] font-mono uppercase tracking-[0.1em] px-1.5 py-0.5 rounded bg-primary/15 text-primary border border-primary/30">
              Manual
            </span>
          )}
          {editing ? (
            <div className="flex items-center gap-1 flex-1">
              <Input
                autoFocus value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") onSaveLabel();
                  if (e.key === "Escape") { setDraft(baseLabel); setEditing(false); }
                }}
                className="h-7 text-sm flex-1 max-w-xs"
              />
              <Button size="icon" variant="ghost" className="h-7 w-7" onClick={onSaveLabel}>
                <Check className="h-3.5 w-3.5 text-primary" />
              </Button>
              <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => { setDraft(baseLabel); setEditing(false); }}>
                <X className="h-3.5 w-3.5" />
              </Button>
            </div>
          ) : (
            <>
              <h3 className="text-sm font-bold uppercase tracking-[0.06em] truncate"
                   title={baseLabel}>
                {baseLabel}
              </h3>
              {!readOnly && (
                <button className="text-muted-foreground hover:text-primary p-1 rounded" onClick={() => setEditing(true)} title="Renomear funil">
                  <Pencil className="h-3 w-3" />
                </button>
              )}
            </>
          )}
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <span className="text-[10px] text-muted-foreground/70 hidden sm:inline">
            {isManual ? "manual" : `${campaigns.length} campanha${campaigns.length !== 1 ? "s" : ""}`}
          </span>
          {!readOnly && (
            <Popover>
              <PopoverTrigger asChild>
                <Button size="icon" variant="ghost" className="h-7 w-7 focus-visible:ring-0" title="Escolher / adicionar métricas">
                  <Settings className="h-4 w-4" />
                </Button>
              </PopoverTrigger>
              <PopoverContent align="end" className="w-[320px] p-0 flex flex-col max-h-[60vh] border-border shadow-xl">
                <div className="px-4 py-3 border-b border-border bg-muted/30">
                  <h4 className="text-sm font-semibold tracking-tight">Métricas do Funil</h4>
                  <p className="text-[11px] text-muted-foreground">Arraste para reordenar. Oculte no ícone (✕).</p>
                </div>
                
                <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4 shadow-inner">
                  <div>
                    <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-2">Exibidas ({visibleKeys.length})</div>
                    <Reorder.Group axis="y" values={selected} onReorder={setSelected} className="space-y-1.5 min-h-[50px]">
                      {visibleKeys.map((k) => {
                        const cfg = fullCatalog[k];
                        if (!cfg) return null;
                        return (
                          <Reorder.Item key={k} value={k} className="flex items-center gap-2 bg-card border border-border/50 rounded-md px-2.5 py-1.5 text-xs shadow-sm cursor-grab active:cursor-grabbing hover:border-primary/30">
                            <GripVertical className="h-3.5 w-3.5 text-muted-foreground/50 shrink-0" />
                            <span className="flex-1 font-medium truncate">{cfg.label}</span>
                            <button onClick={() => toggleKpi(k)} className="p-1 hover:bg-destructive/10 hover:text-destructive rounded-sm text-muted-foreground transition-colors shrink-0">
                              <X className="h-3 w-3" />
                            </button>
                          </Reorder.Item>
                        );
                      })}
                    </Reorder.Group>
                  </div>
                  
                  {Object.keys(fullCatalog).filter(k => !visibleKeys.includes(k)).length > 0 && (
                    <div>
                      <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-2">Disponíveis</div>
                      <div className="flex flex-wrap gap-1.5">
                        {Object.keys(fullCatalog).filter(k => !visibleKeys.includes(k)).map(k => {
                          const cfg = fullCatalog[k];
                          return (
                            <button
                              key={k}
                              onClick={() => toggleKpi(k)}
                              className="px-2 py-1 bg-muted hover:bg-primary/10 hover:text-primary hover:border-primary/30 border border-transparent rounded text-[11px] font-medium transition-colors flex items-center gap-1"
                            >
                              <Plus className="h-3 w-3" /> {cfg.label}
                            </button>
                          )
                        })}
                      </div>
                    </div>
                  )}

                  <div className="pt-3 border-t border-border/60">
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-2">
                       Nova Métrica Personalizada
                    </p>
                    <div className="flex flex-col gap-2">
                      <Input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Nome (ex.: Inscritos)" className="h-8 text-xs bg-muted/50" />
                      <div className="flex gap-2">
                        <Input type="number" step="0.01" value={newValue} onChange={(e) => setNewValue(e.target.value)} placeholder="Valor Inicial" className="h-8 text-xs flex-1 bg-muted/50" />
                        <Button size="sm" onClick={handleAddCustom} disabled={saveMetric.isPending} className="h-8 px-3 text-xs gap-1 shrink-0">
                          <Plus className="h-3 w-3" /> Add
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-3 border-t border-border bg-muted/30">
                  <PopoverClose asChild>
                    <Button variant="outline" className="w-full h-8 text-xs">Concluir</Button>
                  </PopoverClose>
                </div>
              </PopoverContent>
            </Popover>
          )}
          {isManual && manualId && !readOnly && (
            <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive hover:text-destructive" title="Remover funil manual" onClick={handleDeleteManual}>
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          )}
          {!hideOpenDetail && (
          <Button
            size="sm" variant="outline"
            className="h-7 text-[11px] gap-1 border-primary/40 text-primary hover:bg-primary/10 hover:text-primary"
            onClick={onOpenDetail}
          >
            Análise completa <ArrowRight className="h-3 w-3" />
          </Button>)}
        </div>
      </header>

      {visible.length > 0 ? (
        <Reorder.Group 
          axis="x" 
          values={selected} 
          onReorder={setSelected} 
          className="grid gap-3 p-4 layout-grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6"
        >
          {visible.map((key) => {
            const cfg = fullCatalog[key];
            if (!cfg) return null;
            const display = formatValue(cfg.value, cfg.format, currencySymbol, isManual && !cfg.isManualOverride);
            return (
              <Reorder.Item key={key} value={key} className="h-full relative group min-w-0 flex">
                <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity z-10 cursor-grab active:cursor-grabbing p-1 rounded-sm hover:bg-muted bg-card border border-border/40">
                  <GripHorizontal className="h-3 w-3 text-muted-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <EditableKpiCell
                    clientId={clientId}
                    funnelCode={funnelCode}
                    metricKey={cfg.key}
                    metricLabel={cfg.label}
                    displayLabel={cfg.label}
                    displayValue={display}
                    sub={cfg.sub}
                    icon={cfg.icon}
                    emphasis={cfg.emphasis}
                    rawValue={cfg.value}
                    isManualOverride={cfg.isManualOverride}
                    isCustomMetric={cfg.isCustom}
                    onCustomRemoved={() => setSelected((p) => p.filter((k) => k !== cfg.key))}
                    datePreset={datePreset}
                    readOnly={readOnly}
                  />
                </div>
              </Reorder.Item>
            );
          })}
        </Reorder.Group>
      ) : (
         <div className="p-8 text-center text-xs text-muted-foreground">
            Nenhuma métrica selecionada. Clique na engrenagem para adicionar.
         </div>
      )}
    </motion.section>
  );
}