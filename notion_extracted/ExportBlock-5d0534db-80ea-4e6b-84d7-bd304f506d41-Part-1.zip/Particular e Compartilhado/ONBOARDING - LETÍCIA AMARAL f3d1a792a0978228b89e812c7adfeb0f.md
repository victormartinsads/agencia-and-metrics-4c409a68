# ONBOARDING - LETÍCIA AMARAL

Responsável: Eduardo, Letícia Amaral
Status: Concluído

- 🔐  **SENHAS DE ACESSO**
    - `Instagram do Letícia Amaral:`
    Login: tributaristadofuturo
        
        Senha: TDFinst@25
        
    - `Instagram do IBPT:`
    Login: [ibpt.la](http://ibpt.la/)
        
        Senha: IBPTLAinst@25
        
    - `Clint:`
        
        [https://app.clint.digital/login](https://app.clint.digital/login)
        
        Login: [diretoria@ibpteducacao.com.br](mailto:diretoria@ibpteducacao.com.br)
        Senha: Ibptla2@24
        
    
    🚨 `ACESSO AOS ATIVOS GOOGLE E META`
    
    - [x]  ADM BM FB Ads
    - [x]  Mandar invite para gestores

- **PREPARAÇÃO PRÉ CALL**
    - CRIAÇÃO
        - [x]  Emissão do contrato / Adobe Acrobat
        - [x]  Criar grupo no WhatsApp
        - [x]  Criar Dashboard no Notion
        - [x]  Criar pasta no Drive
    - DOCUMENTOS (Enviar para o cliente no grupo e pedir para ele preencher):
        - [x]  ICP - AND
            
            [https://docs.google.com/document/d/1Pe7qdR8yI9_HxYDK6rv5UM3RHrDTIZ-piuQWXLOK13Y/edit?usp=sharing](https://docs.google.com/document/d/1Pe7qdR8yI9_HxYDK6rv5UM3RHrDTIZ-piuQWXLOK13Y/edit?usp=sharing)
            
        - [x]  PRODUTOS
            
            [https://docs.google.com/document/d/12Fx5rstJOfBJzTgdCfhdTCt4SIigXcH4TJXXov59Ync/edit?usp=sharing](https://docs.google.com/document/d/12Fx5rstJOfBJzTgdCfhdTCt4SIigXcH4TJXXov59Ync/edit?usp=sharing)
            
- **ON BOARDING CALL**
    - ALINHAMENTO:
        - [x]  Mostrar o Dashboard no Notion e alinhar com o cliente
        - [x]  Convidar cliente para o Notion
        - [x]  Criar lista de público (Com min 50 Email, nome e número de telefone)
        - [x]  Revisar as respostas do ICP;
        - [x]  Revisar as respostas dos produtos e auxiliar na estrutação dos produtos;
    - GERENCIAMENTO:
        - Conta de anúncios que será utilizada para Mentoria: IBPT Edu | 5 | Cartão | Lançamento, Mentoria, Mundo FTF
        - Conta de anúncios que será utilizada para Consultoria: Será criada
        - Verba que será utilizada no mês para Dra Letícia Amaral - Mentoria: R$25.000,00 = R$833,33
        - Verba que será utilizada no mês para IBPT - Consultoria: R$25.000,00 = R$833,33
        - Forma de pagamento: Cartão de Crédito
        - Sites - Mentoria (Letícia Amaral):
            1. Advogado: https://tributaristadofuturo.com.br/pg-aplicacao/
            2. Contador: [https://tributaristadofuturo.com.br/pg-aplicacao-2/](https://tributaristadofuturo.com.br/pg-aplicacao-2/)
        - Sites - Consultoria (IBPT):
            1. [https://ibptla.com.br/aplicar/](https://ibptla.com.br/aplicar/)
        - Quais são os membros da equipe:
            - Letícia Amaral: Expert
            - Marcos Ribeiro: Diretor de Marketing
            - Eveline: Financeiro
            - Thalita: Webdesigner
            - Nara: Diretora Comercial
            - Vinícius: Assistente de Marketing
            
    - ESTRATÉGIAS:
        1. ORÇAMENTO TOTAL - MENTORIA: R$25.000,00/Mês = R$833,33/Dia
            - FUNIL 01 - (Captação de Seguidores) - (R$166,66/Dia - R$5.000,00/Mês) | ADS ⮕ Perfil do Instagram ⮕ Stories ou Boas Vindas no Direct ⮕ Reunião ⮕ ****Venda
            - FUNIL 02 - (Sessão Estratégica - Público Frio) - (Verba: R$500,00/Dia - R$15.000,00/Mês) | ADS ⮕ LP ⮕ Formulário ⮕ Reunião ⮕ Venda
            - FUNIL 03 - (Sessão Estratégica - Público Quente) - (Verba: R$166,66/Dia - R$5.000,00/Mês) | ADS ⮕ LP ⮕ Formulário ⮕ Reunião ⮕ Venda
        
        1. ORÇAMENTO TOTAL - CONSULTORIA: R$25.000,00/Mês = R$833,33/Dia
            - FUNIL 01 - (Captação de Seguidores) - (R$166,66/Dia - R$5.000,00) | ADS ⮕ Perfil do Instagram ⮕ Stories ou Boas Vindas no Direct ⮕ Reunião ⮕ ****Venda
            - FUNIL 02 - (Sessão Estratégica - Público Frio) - (Verba: R$500,00/Dia - R$15.000,00/Mês) | ADS ⮕ LP ⮕ Formulário ⮕ Reunião ⮕ Venda
            - FUNIL 03 - (Sessão Estratégica - Público Quente) - (Verba: R$166,66/Dia - R$5.000,00/Mês) | ADS ⮕ LP ⮕ Formulário ⮕ Reunião ⮕ Venda
    - DADOS:
        - Histórico:
            - Algum criativo já deu muito certo? (Trouxe algum tipo de resultados)